"""
Custom Django middleware for the Heart Disease Prediction project.
"""

import time
import logging
from django.shortcuts import redirect
from django.urls import reverse
from django.conf import settings

logger = logging.getLogger(__name__)


class LoginRequiredMiddleware:
    """
    Middleware that forces a user to be logged in for all views except those
    explicitly whitelisted (e.g., login, register, password reset, static assets).
    """
    EXEMPT_URLS = [
        reverse('login'),
        reverse('register'),
        reverse('password_reset'),
        reverse('password_reset_done'),
        reverse('password_reset_confirm'),
        reverse('password_reset_complete'),
        '/admin/',
        '/static/',
        '/media/',
    ]

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if not request.user.is_authenticated:
            # Check if the requested path is exempt
            path = request.path_info
            if not any(path.startswith(url) for url in self.EXEMPT_URLS):
                return redirect(settings.LOGIN_URL)
        return self.get_response(request)


class RequestTimingMiddleware:
    """
    Logs the time taken to process each request.
    Useful for performance monitoring.
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        start_time = time.time()
        response = self.get_response(request)
        duration = time.time() - start_time
        if duration > 0.5:  # log slow requests (>500ms)
            logger.warning(
                f"Slow request: {request.method} {request.path} took {duration:.2f}s"
            )
        return response


class SecurityHeadersMiddleware:
    """
    Adds security-related headers to every response.
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        # Prevent MIME type sniffing
        response['X-Content-Type-Options'] = 'nosniff'
        # Enable XSS filtering
        response['X-XSS-Protection'] = '1; mode=block'
        # Prevent clickjacking
        response['X-Frame-Options'] = 'DENY'
        # Strict Transport Security (use only in production with HTTPS)
        if not settings.DEBUG:
            response['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        return response