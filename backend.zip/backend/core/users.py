import json
import os

USERS_FILE = 'users.json'

def load_users_from_file():
    """Load users_db from JSON file (if exists)."""
    global users_db, next_user_id
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, 'r') as f:
                data = json.load(f)
                users_db = data.get('users_db', {})
                next_user_id = data.get('next_user_id', 4)
                # Ensure admin/doctor/patient are always present (optional)
                for default_username, default_data in [('admin', 'admin123'), ('doctor', 'pass123'), ('patient', 'patient123')]:
                    if default_username not in users_db:
                        users_db[default_username] = {
                            'id': next_user_id,
                            'password': default_data[1],
                            'name': f'System {default_username.capitalize()}',
                            'email': f'{default_username}@medpredict.com',
                            'role': default_username,
                            'created_at': datetime.now().strftime('%Y-%m-%d')
                        }
                        next_user_id += 1
        except Exception as e:
            print(f"Error loading users: {e}")

def save_users_to_file():
    """Save users_db to JSON file."""
    global users_db, next_user_id
    try:
        with open(USERS_FILE, 'w') as f:
            json.dump({'users_db': users_db, 'next_user_id': next_user_id}, f, indent=2)
    except Exception as e:
        print(f"Error saving users: {e}")