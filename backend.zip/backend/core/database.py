"""
Database utilities for the Heart Disease Prediction project.
Includes a database router for read/write splitting (if multiple DBs) and health checks.
"""

from django.conf import settings
from django.db import connections
from django.db.utils import OperationalError


class PrimaryReplicaRouter:
    """
    A database router that directs read queries to a replica (if configured)
    and write queries to the primary.
    Requires settings.DATABASES to have 'default' (primary) and 'replica' keys.
    """
    def db_for_read(self, model, **hints):
        """Send reads to the 'replica' database if it exists, otherwise 'default'."""
        if 'replica' in settings.DATABASES:
            return 'replica'
        return 'default'

    def db_for_write(self, model, **hints):
        """All writes go to 'default'."""
        return 'default'

    def allow_relation(self, obj1, obj2, **hints):
        """Allow relations only if both objects are in the same database."""
        db1 = getattr(obj1, '_state', None)
        db2 = getattr(obj2, '_state', None)
        if db1 and db2 and db1.db != db2.db:
            return False
        return True

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        """Only the 'default' database receives migrations."""
        return db == 'default'


def check_database_health():
    """
    Verifies that the default database is reachable and returns a status.
    Used by health check endpoints or management commands.
    """
    result = {
        'default': {'status': 'ok', 'error': None},
    }
    try:
        connections['default'].cursor()
    except OperationalError as e:
        result['default'] = {'status': 'error', 'error': str(e)}
    return result


def get_connection_pool_stats():
    """
    Placeholder for connection pool statistics.
    Requires django-db-pool or similar extension; otherwise returns a message.
    """
    return {
        'pool_size': 'N/A (no pooling configured)',
        'connection_usage': 'N/A',
    }


def close_old_connections():
    """
    Close stale database connections.
    Can be called from cron jobs or long‑running tasks.
    """
    from django.db import close_old_connections as django_close_old
    django_close_old()


class DatabaseHealthCheckMixin:
    """
    Mixin for Django views to include a database health check.
    Example:
        from django.views.generic import View
        from backend.core.database import DatabaseHealthCheckMixin

        class HealthView(DatabaseHealthCheckMixin, View):
            def get(self, request):
                return JsonResponse(self.db_health_status)
    """
    @property
    def db_health_status(self):
        return check_database_health()