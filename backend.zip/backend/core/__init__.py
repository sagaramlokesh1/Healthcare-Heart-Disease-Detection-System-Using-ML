"""
Core Django configuration for authentication backend.
"""