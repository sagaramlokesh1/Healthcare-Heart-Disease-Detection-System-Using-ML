from .models import PredictionHistory

class RecommendationEngine:
    """Generate personalized recommendations based on risk scores and clinical data."""

    @staticmethod
    def get_lifestyle_advice(risk_score, smoker, diabetic, bp_high):
        """Return text recommendations."""
        advice = []
        if risk_score > 0.6:
            advice.append("Immediate cardiologist consultation advised.")
        elif risk_score > 0.3:
            advice.append("Lifestyle changes and follow-up in 3 months.")
        else:
            advice.append("Maintain healthy habits.")

        if smoker:
            advice.append("Smoking cessation is critical. Consider nicotine replacement therapy.")
        if diabetic:
            advice.append("Optimize blood sugar control. Regular HbA1c monitoring.")
        if bp_high:
            advice.append("Monitor blood pressure daily. Reduce sodium intake.")
        return " ".join(advice)

    @staticmethod
    def get_dietary_suggestions(cholesterol, glucose):
        """Return diet tips based on lab values."""
        tips = []
        if cholesterol > 200:
            tips.append("Reduce saturated fats; increase fiber (oats, beans).")
        if glucose > 140:
            tips.append("Low glycemic index foods; avoid sugary drinks.")
        if not tips:
            tips.append("Continue balanced Mediterranean diet.")
        return tips

    @staticmethod
    def generate_plan(prediction_id):
        """Create a full recommendation plan from a prediction."""
        pred = PredictionHistory.objects.get(id=prediction_id)
        risk = pred.ml_risk_score
        bp_high = pred.systolic_bp > 140
        lifestyle = RecommendationEngine.get_lifestyle_advice(risk, pred.smoker, pred.diabetic, bp_high)
        diet = RecommendationEngine.get_dietary_suggestions(pred.cholesterol, 0)  # glucose not in snapshot
        return {
            'lifestyle': lifestyle,
            'diet': diet,
            'next_checkup': '3 months' if risk > 0.3 else '1 year',
        }