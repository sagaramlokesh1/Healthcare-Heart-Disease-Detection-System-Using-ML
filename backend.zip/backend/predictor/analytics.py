"""
Analytics and dashboard metrics.
"""
from django.db.models import Sum, Avg, Count, Q
from django.utils import timezone
from datetime import timedelta
from typing import Dict, Any
from .models import SalesPrediction, HistoricalSales, Product


def get_analytics_dashboard(days_back: int = 30) -> Dict[str, Any]:
    """
    Generate comprehensive analytics dashboard data.
    
    Args:
        days_back: Days to look back for metrics
        
    Returns:
        Dashboard metrics dictionary
    """
    cutoff_date = timezone.now().date() - timedelta(days=days_back)
    
    # Prediction metrics
    predictions = SalesPrediction.objects.filter(created_at__gte=cutoff_date)
    high_confidence = predictions.filter(confidence_score__gte=0.85)
    
    # Revenue metrics
    total_predicted_revenue = predictions.aggregate(
        total=Sum('predicted_revenue')
    )['total'] or 0
    
    # Product performance
    top_products = Product.objects.filter(
        predictions__confidence_score__gte=0.7
    ).annotate(
        pred_count=Count('predictions'),
        avg_confidence=Avg('predictions__confidence_score'),
        total_revenue=Sum('predictions__predicted_revenue')
    ).order_by('-total_revenue')[:5]
    
    return {
        'total_predictions': predictions.count(),
        'high_confidence_predictions': high_confidence.count(),
        'avg_confidence': predictions.aggregate(avg=Avg('confidence_score'))['avg'] or 0,
        'total_predicted_revenue': float(total_predicted_revenue),
        'top_products': list(top_products.values('name', 'pred_count', 'avg_confidence', 'total_revenue')),
        'prediction_accuracy': _calculate_overall_accuracy(predictions),
        'recent_activity': predictions.count() > 0
    }


def _calculate_overall_accuracy(predictions) -> Dict[str, float]:
    """Calculate prediction accuracy metrics."""
    # This is a simplified accuracy calculation
    # In production, match predictions to actual sales
    avg_confidence = predictions.aggregate(avg=Avg('confidence_score'))['avg'] or 0
    return {
        'confidence_score': float(avg_confidence),
        'match_rate': 0.0  # Would require actual sales matching
    }


def get_product_performance(product_id: int) -> Dict[str, Any]:
    """Get detailed performance metrics for a product."""
    product = Product.objects.get(id=product_id)
    
    return {
        'product_name': product.name,
        'total_predictions': product.predictions.count(),
        'avg_confidence': float(product.predictions.aggregate(avg=Avg('confidence_score'))['avg'] or 0),
        'total_predicted_revenue': float(product.predictions.aggregate(total=Sum('predicted_revenue'))['total'] or 0),
        'historical_sales_count': product.historical_sales.count()
    }