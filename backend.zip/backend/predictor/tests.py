"""
Comprehensive test suite for predictor app.
"""
import pytest
from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from datetime import date, timedelta
from unittest.mock import patch, MagicMock

from .models import Product, HistoricalSales, SalesPrediction, ProductCategory
from .services import SalesPredictionService
from .ml_utils import SalesPredictor
from .validators import validate_sales_date, validate_discount_range


@pytest.mark.django_db
class ModelTests(TestCase):
    """Test database models."""
    
    def setUp(self):
        self.category = ProductCategory.objects.create(name="Electronics")
        self.product = Product.objects.create(
            name="Test Product",
            category=self.category,
            sku="TEST001",
            base_price=25.99
        )
    
    def test_product_creation(self):
        product = Product.objects.create(
            name="Valid Product",
            category=self.category,
            sku="VALID123",
            base_price=19.99
        )
        self.assertEqual(product.name, "Valid Product")
    
    def test_sales_prediction_unique_id(self):
        pred1 = SalesPrediction.objects.create(
            product=self.product,
            prediction_date=date.today(),
            predicted_units=100,
            predicted_revenue=2599.00,
            confidence_score=0.85
        )
        pred2 = SalesPrediction.objects.create(
            product=self.product,
            prediction_date=date.today() + timedelta(days=1),
            predicted_units=120,
            predicted_revenue=3118.80,
            confidence_score=0.92
        )
        self.assertNotEqual(pred1.id, pred2.id)


@pytest.mark.django_db
class ServiceTests(TestCase):
    """Test business logic services."""
    
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='testpass')
        self.category = ProductCategory.objects.create(name="Test Category")
        self.product = Product.objects.create(
            name="Test Product",
            category=self.category,
            sku="TEST123",
            base_price=20.00
        )
    
    @patch('predictor.services.SalesPredictor')
    def test_create_predictions(self, mock_predictor):
        """Test prediction creation service."""
        mock_instance = MagicMock()
        mock_predictor.return_value = mock_instance
        mock_instance.prepare_features.return_value = np.array([[1,2,3]])
        mock_instance.predict.return_value = {
            'units': 100.0,
            'revenue': 2000.0,
            'confidence': 0.85
        }
        
        predictions, errors = SalesPredictionService.create_predictions(
            product_ids=[self.product.id],
            days_ahead=7,
            user=self.user
        )
        
        self.assertEqual(len(predictions), 1)
        self.assertEqual(len(errors), 0)
        self.assertEqual(predictions[0].product, self.product)


@pytest.mark.django_db
class ViewTests(TestCase):
    """Test Django views."""
    
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(username='testuser', password='testpass')
        self.client.login(username='testuser', password='testpass')
        
        self.category = ProductCategory.objects.create(name="Test")
        self.product = Product.objects.create(
            name="Test Product",
            category=self.category,
            sku="TEST001",
            base_price=25.99
        )
    
    def test_product_list_view(self):
        """Test product list view."""
        response = self.client.get(reverse('predictor:product_list'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'predictor/product_list.html')
    
    def test_predict_sales_post(self):
        """Test prediction endpoint."""
        data = {
            'product_ids': [self.product.id],
            'days_ahead': 7
        }
        response = self.client.post(
            reverse('predictor:predict_sales'),
            json.dumps(data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)


class ValidatorTests(TestCase):
    """Test custom validators."""
    
    def test_validate_sales_date_future(self):
        """Test future date validation."""
        future_date = date.today() + timedelta(days=1)
        with self.assertRaises(ValidationError):
            validate_sales_date(future_date)
    
    def test_validate_discount_range(self):
        """Test discount range validation."""
        validate_discount_range(0.5)  # Should pass
        with self.assertRaises(ValidationError):
            validate_discount_range(1.5)
        with self.assertRaises(ValidationError):
            validate_discount_range(-0.1)