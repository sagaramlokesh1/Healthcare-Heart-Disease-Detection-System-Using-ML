from datetime import datetime, timedelta
from django.db import models
from django.utils import timezone

# If you want persistent appointments, create a model; otherwise use in‑memory.
# Here we provide a service that could use an Appointment model (not included yet).

class AppointmentManager:
    """Service to handle patient appointments (schedule, reminders, etc.)."""

    @staticmethod
    def create_appointment(patient_id, doctor_name, appointment_date, reason):
        """Store appointment (you should create an Appointment model)."""
        # Placeholder – implement with a model if needed.
        return {
            'id': 1,
            'patient_id': patient_id,
            'doctor': doctor_name,
            'date': appointment_date,
            'reason': reason,
            'status': 'scheduled'
        }

    @staticmethod
    def get_upcoming_appointments(patient_id, days_ahead=30):
        """Retrieve appointments in next N days."""
        # Mock implementation – replace with DB query.
        now = timezone.now()
        upcoming = []
        for i in range(1, 4):
            upcoming.append({
                'date': now + timedelta(days=i*7),
                'doctor': 'Dr. Smith',
                'reason': 'Follow-up'
            })
        return upcoming

    @staticmethod
    def reschedule_appointment(appointment_id, new_date):
        """Change appointment date."""
        return {'success': True, 'new_date': new_date}

    @staticmethod
    def cancel_appointment(appointment_id):
        """Cancel appointment."""
        return {'success': True}