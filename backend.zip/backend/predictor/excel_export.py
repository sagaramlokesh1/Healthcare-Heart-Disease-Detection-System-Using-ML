"""
Excel export utilities using openpyxl.
"""
from django.http import HttpResponse
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
import pandas as pd
from io import BytesIO
from .models import SalesPrediction
from .constants import EXCEL_SHEET_NAME


def export_predictions_to_excel(predictions) -> HttpResponse:
    """
    Export predictions to formatted Excel file.
    
    Args:
        predictions: Queryset of SalesPrediction objects
        
    Returns:
        HttpResponse with Excel attachment
    """
    buffer = BytesIO()
    
    # Create workbook
    wb = Workbook()
    ws = wb.active
    ws.title = EXCEL_SHEET_NAME
    
    # Prepare data
    data = []
    for prediction in predictions:
        data.append({
            'Product': prediction.product.name,
            'SKU': prediction.product.sku,
            'Date': prediction.prediction_date.strftime('%Y-%m-%d'),
            'Predicted Units': prediction.predicted_units,
            'Predicted Revenue': prediction.predicted_revenue,
            'Confidence': prediction.confidence_score,
            'Status': prediction.status
        })
    
    df = pd.DataFrame(data)
    
    # Write data
    for r in dataframe_to_rows(df, index=False, header=True):
        ws.append(r)
    
    # Apply formatting
    _format_excel_worksheet(ws)
    
    # Write to buffer
    wb.save(buffer)
    buffer.seek(0)
    
    response = HttpResponse(
        buffer.getvalue(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = 'attachment; filename=sales_predictions.xlsx'
    return response


def _format_excel_worksheet(ws):
    """Apply professional formatting to worksheet."""
    # Header formatting
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_alignment = Alignment(horizontal="center", vertical="center")
    
    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
    
    # Data formatting
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Currency and percentage formatting
    for row in ws.iter_rows(min_row=2, max_col=6):
        for cell in row:
            cell.border = thin_border
            if cell.column == 5:  # Revenue
                cell.number_format = '$#,##0.00'
            elif cell.column == 6:  # Confidence
                cell.number_format = '0.00%'
    
    # Auto-adjust column widths
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 20)
        ws.column_dimensions[column_letter].width = adjusted_width