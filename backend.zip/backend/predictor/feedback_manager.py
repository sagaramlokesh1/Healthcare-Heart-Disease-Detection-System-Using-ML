from django.db import models
from django.utils import timezone

# Optional: create a Feedback model if you want persistence
# class Feedback(models.Model):
#     user = models.ForeignKey(User, ...)
#     rating = models.IntegerField()
#     comment = models.TextField()
#     created_at = models.DateTimeField(auto_now_add=True)

class FeedbackManager:
    """Handle patient/doctor feedback and surveys."""

    @staticmethod
    def submit_feedback(user_id, rating, comment, category='general'):
        """Store feedback (you need a Feedback model)."""
        # Placeholder – implement with model.
        # Feedback.objects.create(user_id=user_id, rating=rating, comment=comment, category=category)
        return {'success': True, 'feedback_id': 1}

    @staticmethod
    def get_average_rating():
        """Calculate average rating from all feedback."""
        # Placeholder – query the Feedback model.
        return 4.5

    @staticmethod
    def get_feedback_summary(days=30):
        """Return recent feedback counts by rating."""
        # Placeholder – implement with real data.
        return {
            'total': 42,
            'positive': 35,
            'negative': 7,
            'common_keywords': ['easy to use', 'accurate', 'helpful']
        }

    @staticmethod
    def send_feedback_thankyou_email(user_email):
        """Send acknowledgment after feedback submission."""
        # Use NotificationManager
        from .notification_manager import NotificationManager
        NotificationManager.send_email_notification(
            user_email,
            "Thank you for your feedback",
            "We appreciate your input to improve MedPredict."
        )