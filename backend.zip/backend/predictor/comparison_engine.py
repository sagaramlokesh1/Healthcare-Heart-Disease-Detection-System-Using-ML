from .models import Patient, PredictionHistory

class ComparisonEngine:
    """Compare risk profiles between patients or over time."""

    @staticmethod
    def compare_patients(patient_id1, patient_id2):
        """Compare latest risk scores and key metrics."""
        p1 = Patient.objects.get(id=patient_id1)
        p2 = Patient.objects.get(id=patient_id2)
        last_pred1 = p1.predictions.order_by('-prediction_date').first()
        last_pred2 = p2.predictions.order_by('-prediction_date').first()

        return {
            'patient1': {
                'name': f"{p1.first_name} {p1.last_name}",
                'age': p1.age,
                'risk_score': last_pred1.ml_risk_score if last_pred1 else None,
                'smoker': last_pred1.smoker if last_pred1 else None,
            },
            'patient2': {
                'name': f"{p2.first_name} {p2.last_name}",
                'age': p2.age,
                'risk_score': last_pred2.ml_risk_score if last_pred2 else None,
                'smoker': last_pred2.smoker if last_pred2 else None,
            }
        }

    @staticmethod
    def compare_before_after(patient_id, before_date, after_date):
        """Compare risk before and after an intervention date."""
        before_pred = PredictionHistory.objects.filter(
            patient_id=patient_id, prediction_date__lte=before_date
        ).order_by('-prediction_date').first()
        after_pred = PredictionHistory.objects.filter(
            patient_id=patient_id, prediction_date__gte=after_date
        ).order_by('prediction_date').first()

        return {
            'before': {'date': before_pred.prediction_date, 'risk': before_pred.ml_risk_score} if before_pred else None,
            'after': {'date': after_pred.prediction_date, 'risk': after_pred.ml_risk_score} if after_pred else None,
            'change': (after_pred.ml_risk_score - before_pred.ml_risk_score) if (before_pred and after_pred) else None,
        }