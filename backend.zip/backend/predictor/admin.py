"""
Django admin configuration for predictor app.
"""
from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe

from .models import ProductCategory, Product, HistoricalSales, SalesPrediction


@admin.register(ProductCategory)
class ProductCategoryAdmin(admin.ModelAdmin):
    """Admin for product categories."""
    list_display = ['name', 'product_count', 'created_at']
    list_filter = ['created_at']
    search_fields = ['name', 'description']
    
    def product_count(self, obj):
        return obj.products.count()
    product_count.short_description = 'Products'


class HistoricalSalesInline(admin.TabularInline):
    """Inline for historical sales."""
    model = HistoricalSales
    fields = ['date', 'units_sold', 'revenue', 'promotional_discount']
    extra = 0
    readonly_fields = ['date', 'units_sold', 'revenue']
    ordering = ['-date']


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    """Admin for products."""
    list_display = ['name', 'sku', 'category', 'base_price', 'sales_count', 'view_predictions']
    list_filter = ['category', 'created_at']
    search_fields = ['name', 'sku']
    inlines = [HistoricalSalesInline]
    fieldsets = (
        ('Product Info', {
            'fields': ('name', 'sku', 'category', 'base_price')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def sales_count(self, obj):
        return obj.historical_sales.count()
    sales_count.short_description = 'Total Sales Records'
    
    def view_predictions(self, obj):
        url = reverse('admin:predictor_salesprediction_changelist') + f'?product__id__exact={obj.id}'
        return format_html('<a href="{}">View</a>', url)
    view_predictions.short_description = 'Predictions'


@admin.register(HistoricalSales)
class HistoricalSalesAdmin(admin.ModelAdmin):
    """Admin for historical sales data."""
    list_display = ['product', 'date', 'units_sold', 'revenue', 'discount_display', 'created_by']
    list_filter = ['date', 'product__category', 'created_at']
    search_fields = ['product__name', 'product__sku']
    date_hierarchy = 'date'
    ordering = ['-date']
    
    def discount_display(self, obj):
        return f"{obj.promotional_discount:.1%}"
    discount_display.short_description = 'Discount'


@admin.register(SalesPrediction)
class SalesPredictionAdmin(admin.ModelAdmin):
    """Admin for sales predictions."""
    list_display = ['product', 'prediction_date', 'predicted_units', 
                   'predicted_revenue', 'confidence_score', 'status', 'view_on_site']
    list_filter = ['status', 'confidence_score', 'created_at', 'product__category']
    search_fields = ['product__name', 'product__sku']
    date_hierarchy = 'created_at'
    ordering = ['-created_at']
    readonly_fields = ['id', 'created_at', 'updated_at']
    
    fieldsets = (
        ('Prediction', {
            'fields': ('product', 'prediction_date', 'predicted_units', 
                      'predicted_revenue', 'confidence_score', 'status')
        }),
        ('Audit', {
            'fields': ('created_by', 'created_at', 'updated_at', 'error_message'),
            'classes': ('collapse',)
        }),
    )
    
    def view_on_site(self, obj):
        url = reverse('predictor:prediction_detail', args=[obj.id])
        return format_html('<a href="{}" target="_blank">View</a>', url)
    view_on_site.short_description = 'Frontend'