from django.db.models import Q
from .models import Patient, Visit, PredictionHistory

class SearchRecords:
    """Advanced search across patient records, visits, and predictions."""

    @staticmethod
    def search_patients(query):
        """Search by name, phone, email, or address."""
        if not query:
            return Patient.objects.none()
        return Patient.objects.filter(
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(phone__icontains=query) |
            Q(email__icontains=query) |
            Q(address__icontains=query)
        ).distinct()

    @staticmethod
    def search_visits(patient_id=None, from_date=None, to_date=None, bp_high=None):
        """Filter visits by date and BP criteria."""
        qs = Visit.objects.all()
        if patient_id:
            qs = qs.filter(patient_id=patient_id)
        if from_date:
            qs = qs.filter(visit_date__gte=from_date)
        if to_date:
            qs = qs.filter(visit_date__lte=to_date)
        if bp_high:
            qs = qs.filter(systolic_bp__gt=140)
        return qs.order_by('-visit_date')

    @staticmethod
    def search_predictions(risk_min=None, risk_max=None, risk_class=None):
        """Filter predictions by ML risk score range."""
        qs = PredictionHistory.objects.all()
        if risk_min is not None:
            qs = qs.filter(ml_risk_score__gte=risk_min)
        if risk_max is not None:
            qs = qs.filter(ml_risk_score__lte=risk_max)
        if risk_class is not None:
            qs = qs.filter(ml_risk_class=risk_class)
        return qs.order_by('-prediction_date')