import sqlite3
import csv
from datetime import datetime
import os

# ─── Get the script's directory ──────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# ─── Look for the database in multiple common locations ──
possible_db_paths = [
    os.path.join(os.path.dirname(SCRIPT_DIR), 'instance', 'medpredict.db'),   # HeartDiseaseProject/instance/medpredict.db
    os.path.join(os.path.dirname(SCRIPT_DIR), 'medpredict.db'),               # HeartDiseaseProject/medpredict.db
    os.path.join(os.path.dirname(SCRIPT_DIR), 'instance', 'heart.db'),
    os.path.join(os.path.dirname(SCRIPT_DIR), 'heart.db'),
    'instance/medpredict.db',                                                 # relative to current working directory
    'medpredict.db',
]

# Pick the first one that exists
DB_PATH = None
for path in possible_db_paths:
    if os.path.exists(path):
        DB_PATH = path
        break

if DB_PATH is None:
    print("❌ Could not find the database file. Please specify the full path.")
    print("   Searched in these locations:")
    for p in possible_db_paths:
        print(f"   - {p}")
    exit(1)

print(f"✅ Using database: {DB_PATH}")

# ─── CSV file in the same folder as this script ──────────
CSV_FILE = os.path.join(SCRIPT_DIR, 'risk_data.csv')

def load_csv():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Check if table exists
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='predictions'")
    if not cursor.fetchone():
        print("❌ Table 'predictions' does not exist in the database.")
        conn.close()
        return

    if not os.path.exists(CSV_FILE):
        print(f"❌ CSV file not found: {CSV_FILE}")
        conn.close()
        return

    with open(CSV_FILE, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        if not rows:
            print("❌ CSV is empty or missing headers.")
            conn.close()
            return

        inserted = 0
        for row in rows:
            smoker = 1 if row['smoker'].strip() in ['1', 'True', 'true', 'Yes', 'yes'] else 0
            diabetic = 1 if row['diabetic'].strip() in ['1', 'True', 'true', 'Yes', 'yes'] else 0
            family_history = 1 if row['family_history'].strip() in ['1', 'True', 'true', 'Yes', 'yes'] else 0
            hypertension = 1 if row['hypertension'].strip() in ['1', 'True', 'true', 'Yes', 'yes'] else 0

            sql = """INSERT INTO predictions 
                     (patient_id, risk_level, probability, smoker, diabetic, family_history, hypertension, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)"""
            cursor.execute(sql, (
                int(row['patient_id']),
                row['risk_level'],
                float(row['probability']),
                smoker,
                diabetic,
                family_history,
                hypertension,
                datetime.now().isoformat()
            ))
            inserted += 1

    conn.commit()
    conn.close()
    print(f"✅ Inserted {inserted} rows from {CSV_FILE}.")
    print("👉 Now visit /analytics to see the Risk Factors chart.")

if __name__ == '__main__':
    load_csv()