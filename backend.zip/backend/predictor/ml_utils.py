"""
Machine learning utilities for sales prediction.
"""
import numpy as np
import pandas as pd
from datetime import date, timedelta
from typing import Dict, List, Any
import joblib
import logging
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

logger = logging.getLogger(__name__)


class SalesPredictor:
    """Sales prediction model with feature engineering."""
    
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self._load_model()
    
    def _load_model(self) -> None:
        """Load pre-trained model or initialize new one."""
        try:
            # In production, load from file
            self.model = joblib.load('sales_model.pkl')
            logger.info("Loaded pre-trained sales model")
        except FileNotFoundError:
            # Initialize new model pipeline
            self.model = Pipeline([
                ('scaler', StandardScaler()),
                ('regressor', RandomForestRegressor(
                    n_estimators=100,
                    max_depth=10,
                    random_state=42,
                    n_jobs=-1
                ))
            ])
            logger.info("Initialized new sales prediction model")
    
    def prepare_features(self, historical_sales: List) -> np.ndarray:
        """
        Convert historical sales to ML features.
        
        Args:
            historical_sales: List of HistoricalSales objects
            
        Returns:
            Feature matrix
        """
        df = pd.DataFrame([
            {
                'date': sale.date,
                'units_sold': sale.units_sold,
                'revenue': float(sale.revenue),
                'discount': float(sale.promotional_discount),
                'day_of_week': sale.date.weekday(),
                'day_of_month': sale.date.day,
                'month': sale.date.month,
                'quarter': (sale.date.month - 1) // 3 + 1,
                'is_weekend': sale.date.weekday() >= 5
            }
            for sale in historical_sales[-90:]  # Last 90 days
        ])
        
        if len(df) < 30:
            raise ValueError("Insufficient historical data")
        
        # Lag features
        for lag in [1, 7, 14, 30]:
            df[f'units_lag_{lag}'] = df['units_sold'].shift(lag)
            df[f'revenue_lag_{lag}'] = df['revenue'].shift(lag)
        
        # Rolling statistics
        df['units_ma_7'] = df['units_sold'].rolling(7).mean()
        df['units_std_7'] = df['units_sold'].rolling(7).std()
        df['revenue_ma_7'] = df['revenue'].rolling(7).mean()
        
        # Fill NaN with forward fill then mean
        df = df.fillna(method='ffill').fillna(df.mean())
        
        feature_cols = [
            'day_of_week', 'day_of_month', 'month', 'quarter', 'is_weekend',
            'units_lag_1', 'units_lag_7', 'units_lag_14', 'units_lag_30',
            'revenue_lag_1', 'revenue_lag_7', 'revenue_lag_14', 'revenue_lag_30',
            'units_ma_7', 'units_std_7', 'revenue_ma_7', 'discount'
        ]
        
        features = df[feature_cols].tail(1).values  # Predict next period
        return features
    
    def predict(self, features: np.ndarray) -> Dict[str, float]:
        """
        Generate sales prediction.
        
        Args:
            features: Prepared feature matrix
            
        Returns:
            Prediction dictionary with confidence
        """
        features_scaled = self.model.named_steps['scaler'].transform(features)
        units_pred = self.model.named_steps['regressor'].predict(features_scaled)[0]
        
        # Calculate confidence based on prediction variance
        prediction_var = self.model.named_steps['regressor'].predict(features_scaled, predict_std=True)
        confidence = np.clip(1 - (prediction_var[1][0] / units_pred), 0.1, 1.0)
        
        # Estimate revenue (units * avg historical price)
        avg_price = 25.0  # Simplified - in production use product price
        revenue_pred = units_pred * avg_price
        
        return {
            'units': max(0, float(units_pred)),
            'revenue': float(revenue_pred),
            'confidence': float(confidence)
        }
    
    def train(self, historical_data: List) -> None:
        """Train model on historical data (for demo purposes)."""
        # In production, this would use much more sophisticated training
        logger.info("Training sales prediction model")
        self.model.fit(np.random.rand(100, 17), np.random.rand(100))  # Demo training
        joblib.dump(self.model, 'sales_model.pkl')