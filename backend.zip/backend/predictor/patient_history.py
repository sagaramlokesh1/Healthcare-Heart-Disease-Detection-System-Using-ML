from datetime import timedelta
from django.utils import timezone
from .models import Patient, Visit, PredictionHistory

class PatientHistoryService:
    """Service to retrieve and analyze patient historical data."""

    @staticmethod
    def get_patient_timeline(patient_id):
        """Return chronological list of visits with predictions."""
        patient = Patient.objects.get(id=patient_id)
        visits = patient.visits.order_by('visit_date')
        timeline = []
        for visit in visits:
            pred = visit.predictions.first()
            timeline.append({
                'date': visit.visit_date,
                'systolic_bp': visit.systolic_bp,
                'diastolic_bp': visit.diastolic_bp,
                'cholesterol': visit.cholesterol,
                'glucose': visit.glucose,
                'risk_score': pred.ml_risk_score if pred else None,
                'risk_class': pred.ml_risk_class if pred else None,
            })
        return timeline

    @staticmethod
    def get_risk_progression(patient_id):
        """Return list of (date, risk_score) for charting."""
        predictions = PredictionHistory.objects.filter(patient_id=patient_id).order_by('prediction_date')
        return [{'date': p.prediction_date, 'risk': p.ml_risk_score} for p in predictions]

    @staticmethod
    def get_last_visit_summary(patient_id):
        """Return most recent visit data."""
        last_visit = Visit.objects.filter(patient_id=patient_id).order_by('-visit_date').first()
        if last_visit:
            pred = last_visit.predictions.first()
            return {
                'date': last_visit.visit_date,
                'bp': f"{last_visit.systolic_bp}/{last_visit.diastolic_bp}",
                'risk': pred.ml_risk_score if pred else None,
                'recommendation': pred.recommendation if pred else None,
            }
        return None