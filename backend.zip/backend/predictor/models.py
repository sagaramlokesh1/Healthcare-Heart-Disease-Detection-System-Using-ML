"""
Predictor app models for Heart Disease Prediction.
"""
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.contrib.auth.models import User
from datetime import date


class Patient(models.Model):
    """Patient demographic and medical history."""
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]
    user = models.OneToOneField(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='patient_profile')
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    phone = models.CharField(max_length=15)
    email = models.EmailField(blank=True)
    address = models.TextField(blank=True)
    medical_history = models.TextField(blank=True, help_text="e.g., Hypertension, Diabetes, etc.")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['first_name', 'last_name']),
            models.Index(fields=['phone']),
            models.Index(fields=['email']),
        ]

    def __str__(self):
        return f"{self.first_name} {self.last_name} (ID: {self.id})"

    @property
    def age(self):
        """Calculate age from date_of_birth."""
        today = date.today()
        return today.year - self.date_of_birth.year - (
            (today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day)
        )

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"


class Visit(models.Model):
    """Patient visit record with clinical measurements."""
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='visits')
    visit_date = models.DateTimeField(auto_now_add=True)
    systolic_bp = models.IntegerField(
        validators=[MinValueValidator(80), MaxValueValidator(250)],
        help_text="Systolic blood pressure (mmHg)"
    )
    diastolic_bp = models.IntegerField(
        validators=[MinValueValidator(40), MaxValueValidator(150)],
        help_text="Diastolic blood pressure (mmHg)"
    )
    cholesterol = models.IntegerField(help_text="Total cholesterol (mg/dL)")
    hdl_cholesterol = models.IntegerField(null=True, blank=True, help_text="HDL cholesterol (mg/dL)")
    glucose = models.IntegerField(help_text="Fasting blood glucose (mg/dL)")
    smoker = models.BooleanField(default=False, help_text="Current smoker")
    diabetic = models.BooleanField(default=False, help_text="Diagnosed diabetes")
    family_history = models.BooleanField(default=False, help_text="Family history of heart disease")
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-visit_date']
        indexes = [
            models.Index(fields=['patient', 'visit_date']),
            models.Index(fields=['visit_date']),
        ]

    def __str__(self):
        return f"Visit {self.id} – {self.patient.full_name} on {self.visit_date.date()}"


class MedicalRecord(models.Model):
    """Chronic conditions and past diagnoses."""
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='medical_records')
    condition = models.CharField(max_length=200, help_text="e.g., Hypertension, Diabetes, Myocardial Infarction")
    diagnosed_date = models.DateField()
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-diagnosed_date']
        indexes = [
            models.Index(fields=['patient', 'condition']),
        ]

    def __str__(self):
        return f"{self.patient.full_name} – {self.condition} ({self.diagnosed_date})"


class PredictionHistory(models.Model):
    """ML and clinical risk predictions for each visit."""
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='predictions')
    visit = models.ForeignKey(Visit, on_delete=models.CASCADE, related_name='predictions')
    prediction_date = models.DateTimeField(auto_now_add=True)

    # ML outputs
    ml_risk_score = models.FloatField(help_text="ML predicted probability (0-1)")
    ml_risk_class = models.IntegerField(help_text="0 = low risk, 1 = high risk")

    # Evidence‑based clinical scores
    framingham_score = models.FloatField(null=True, blank=True, help_text="Framingham 10‑year risk (%)")
    ascvd_score = models.FloatField(null=True, blank=True, help_text="ASCVD 10‑year risk (%)")
    qrisk3_score = models.FloatField(null=True, blank=True, help_text="QRISK3 10‑year risk (%)")

    # Recommendations
    recommendation = models.TextField(blank=True, help_text="Personalized advice")

    # Snapshot of key risk factors (for analytics)
    age = models.IntegerField()
    sex = models.CharField(max_length=1)
    systolic_bp = models.IntegerField()
    cholesterol = models.IntegerField()
    smoker = models.BooleanField()
    diabetic = models.BooleanField()
    family_history = models.BooleanField()

    class Meta:
        ordering = ['-prediction_date']
        indexes = [
            models.Index(fields=['patient', 'prediction_date']),
            models.Index(fields=['ml_risk_class']),
            models.Index(fields=['ml_risk_score']),
        ]

    def __str__(self):
        risk_level = "High" if self.ml_risk_class else "Low"
        return f"Prediction for {self.patient.full_name} on {self.prediction_date.date()} – {risk_level} risk"