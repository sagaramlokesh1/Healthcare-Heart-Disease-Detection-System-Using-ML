from .models import Patient
from django.contrib.auth.models import User

class ProfileManager:
    """Service for patient profile operations."""

    @staticmethod
    def update_patient_profile(patient_id, **kwargs):
        """Update patient fields (first_name, last_name, phone, address, etc.)."""
        patient = Patient.objects.get(id=patient_id)
        for key, value in kwargs.items():
            if hasattr(patient, key):
                setattr(patient, key, value)
        patient.save()
        return patient

    @staticmethod
    def get_patient_summary(patient_id):
        """Return summary for profile page."""
        patient = Patient.objects.get(id=patient_id)
        last_visit = patient.visits.order_by('-visit_date').first()
        return {
            'id': patient.id,
            'name': f"{patient.first_name} {patient.last_name}",
            'age': patient.age,
            'gender': patient.get_gender_display(),
            'phone': patient.phone,
            'email': patient.email,
            'address': patient.address,
            'medical_history': patient.medical_history,
            'last_visit_date': last_visit.visit_date if last_visit else None,
        }

    @staticmethod
    def change_password(user_id, old_password, new_password):
        """Change user password (requires authentication)."""
        user = User.objects.get(id=user_id)
        if user.check_password(old_password):
            user.set_password(new_password)
            user.save()
            return True
        return False