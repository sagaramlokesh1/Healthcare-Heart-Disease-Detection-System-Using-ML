"""
Core business logic services for sales prediction.
"""
from typing import List, Dict, Optional, Tuple
from datetime import date, timedelta
import logging
from django.db import transaction
from django.contrib.auth.models import User
from .models import Product, HistoricalSales, SalesPrediction
from .ml_utils import SalesPredictor
from .validators import validate_historical_data_sequence

logger = logging.getLogger(__name__)


class SalesPredictionService:
    """Main service for sales predictions."""

    @staticmethod
    @transaction.atomic
    def create_predictions(
        product_ids: List[int],
        days_ahead: int,
        user: User,
        confidence_threshold: float = 0.7
    ) -> Tuple[List[SalesPrediction], List[str]]:
        """
        Create batch predictions for multiple products.
        
        Args:
            product_ids: List of product IDs
            days_ahead: Days into future to predict
            user: User creating predictions
            confidence_threshold: Minimum confidence score
            
        Returns:
            Tuple of (created_predictions, errors)
        """
        errors = []
        created_predictions = []
        
        predictor = SalesPredictor()
        
        for product_id in product_ids:
            try:
                product = Product.objects.get(id=product_id)
                prediction = SalesPredictionService._predict_for_product(
                    product, days_ahead, user, predictor, confidence_threshold
                )
                created_predictions.append(prediction)
            except Product.DoesNotExist:
                errors.append(f"Product ID {product_id} not found")
            except Exception as e:
                logger.error(f"Prediction failed for product {product_id}: {str(e)}")
                errors.append(f"Product ID {product_id}: {str(e)}")
        
        return created_predictions, errors

    @staticmethod
    def _predict_for_product(
        product: Product,
        days_ahead: int,
        user: User,
        predictor: SalesPredictor,
        confidence_threshold: float
    ) -> SalesPrediction:
        """Create single product prediction."""
        prediction_date = date.today() + timedelta(days=days_ahead)
        
        # Check historical data sufficiency
        historical_data = list(product.historical_sales.order_by('-date')[:90])
        if len(historical_data) < 30:
            raise ValueError(f"Insufficient historical data ({len(historical_data)} records, need 30+)")
        
        # Generate prediction
        features = predictor.prepare_features(historical_data)
        prediction_result = predictor.predict(features)
        
        if prediction_result['confidence'] < confidence_threshold:
            raise ValueError(f"Low confidence score: {prediction_result['confidence']:.3f}")
        
        # Create prediction record
        prediction = SalesPrediction.objects.create(
            product=product,
            prediction_date=prediction_date,
            predicted_units=prediction_result['units'],
            predicted_revenue=prediction_result['revenue'],
            confidence_score=prediction_result['confidence'],
            created_by=user,
            status='completed'
        )
        
        return prediction

    @staticmethod
    def validate_historical_data(product: Product) -> List[str]:
        """Validate historical data quality."""
        sales_data = list(product.historical_sales.order_by('date').values_list('date', flat=True))
        dates = [sale.date for sale in product.historical_sales.order_by('date')]
        
        errors = []
        try:
            validate_historical_data_sequence(dates, product.id)
        except Exception as e:
            errors.append(str(e))
        
        if len(sales_data) < 30:
            errors.append("Insufficient data points (need at least 30)")
        
        return errors

    @staticmethod
    def get_prediction_accuracy(product_id: int, days_back: int = 30) -> Dict:
        """Calculate prediction accuracy for a product."""
        predictions = SalesPrediction.objects.filter(
            product_id=product_id,
            status='completed',
            prediction_date__gte=date.today() - timedelta(days=days_back)
        )
        
        actual_sales = HistoricalSales.objects.filter(
            product_id=product_id,
            date__gte=date.today() - timedelta(days=days_back)
        )
        
        # Match predictions to actuals and calculate metrics
        accuracy_data = {
            'total_predictions': predictions.count(),
            'matched_predictions': 0,
            'mae_units': 0,
            'mae_revenue': 0,
            'mape_units': 0
        }
        
        return accuracy_data