"""
Django views for the Heart Disease Prediction app.
Features: Patient management, evidence‑based predictions, detailed analytics,
recommendations, notifications, history tracking, ECG analysis.
"""

import json
from datetime import datetime, date
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.views import View
from django.views.decorators.http import require_http_methods
from django.utils.decorators import method_decorator
from django.db.models import Q, Count, Avg
from django.db.models.functions import TruncMonth
from django.core.paginator import Paginator

# Models
from .models import Patient, Visit, MedicalRecord, PredictionHistory

# Forms
from .forms import PatientForm, VisitForm, MedicalRecordForm

# Core services (existing)
from .services import save_prediction_with_scores
from .ml_utils import predict_ml
from .analytics import get_cohort_stats
from .chart_generator import generate_risk_distribution_chart

# NEW service modules
from .recommendation_system import RecommendationSystem
from .notification_service import NotificationService
from .history_manager import HistoryManager
from .analytics_engine import AnalyticsEngine
from .ecg_analysis import ECGAnalysis

# Reporting
from .report_generator import generate_pdf_report
from .csv_export import export_predictions_to_csv
from .excel_export import export_predictions_to_excel


# ------------------------------
# Patient Management Views
# ------------------------------

@login_required
def patient_list(request):
    """List all patients with search and pagination."""
    query = request.GET.get('q', '')
    patients = Patient.objects.all().order_by('-created_at')
    if query:
        patients = patients.filter(
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(phone__icontains=query) |
            Q(email__icontains=query)
        )
    paginator = Paginator(patients, 20)
    page = request.GET.get('page')
    patients_page = paginator.get_page(page)
    return render(request, 'predictor/patients.html', {
        'patients': patients_page,
        'query': query
    })


@login_required
def patient_detail(request, pk):
    """
    Show patient details, visit history, risk timeline.
    Uses HistoryManager for enriched data.
    """
    patient = get_object_or_404(Patient, pk=pk)
    visits = patient.visits.all().order_by('-visit_date')
    predictions = patient.predictions.all().order_by('-prediction_date')

    # Enhanced timeline and risk progression via HistoryManager
    timeline = HistoryManager.get_timeline(patient.id)
    risk_trend = HistoryManager.get_risk_trend(patient.id, months=6)
    vitals_history = HistoryManager.get_vital_signs_history(patient.id)

    context = {
        'patient': patient,
        'visits': visits,
        'predictions': predictions,
        'timeline': timeline,
        'risk_trend': json.dumps(risk_trend),         # for charts
        'vitals_history': json.dumps(vitals_history), # for charts
    }
    return render(request, 'predictor/patient_detail.html', context)


@login_required
def patient_create(request):
    """Create a new patient."""
    if request.method == 'POST':
        form = PatientForm(request.POST)
        if form.is_valid():
            patient = form.save()
            messages.success(request, f'Patient {patient.first_name} {patient.last_name} added.')
            return redirect('predictor:patient_detail', pk=patient.pk)
    else:
        form = PatientForm()
    return render(request, 'predictor/patient_form.html', {'form': form, 'title': 'Add Patient'})


@login_required
def patient_edit(request, pk):
    """Edit patient details."""
    patient = get_object_or_404(Patient, pk=pk)
    if request.method == 'POST':
        form = PatientForm(request.POST, instance=patient)
        if form.is_valid():
            form.save()
            messages.success(request, 'Patient updated.')
            return redirect('predictor:patient_detail', pk=patient.pk)
    else:
        form = PatientForm(instance=patient)
    return render(request, 'predictor/patient_form.html', {'form': form, 'title': 'Edit Patient', 'patient': patient})


@login_required
def add_visit(request, patient_pk):
    """
    Record a new visit, generate prediction, and send high‑risk alerts.
    """
    patient = get_object_or_404(Patient, pk=patient_pk)
    if request.method == 'POST':
        form = VisitForm(request.POST)
        if form.is_valid():
            visit = form.save(commit=False)
            visit.patient = patient
            visit.save()

            # Generate prediction (ML + clinical scores)
            prediction_obj = save_prediction_with_scores(patient, visit)

            # Send high‑risk alert if risk > 70%
            if prediction_obj.ml_risk_score > 0.7:
                NotificationService.alert_high_risk(patient.id, prediction_obj.ml_risk_score)

            messages.success(request, f'Visit recorded. Risk: {prediction_obj.ml_risk_score*100:.1f}%')
            return redirect('predictor:prediction_result', prediction_id=prediction_obj.id)
    else:
        form = VisitForm()
    return render(request, 'predictor/visit_form.html', {'form': form, 'patient': patient})


@login_required
def add_medical_record(request, patient_pk):
    """Add a medical record for a patient."""
    patient = get_object_or_404(Patient, pk=patient_pk)
    if request.method == 'POST':
        form = MedicalRecordForm(request.POST)
        if form.is_valid():
            record = form.save(commit=False)
            record.patient = patient
            record.save()
            messages.success(request, 'Medical record added.')
            return redirect('predictor:patient_detail', pk=patient.pk)
    else:
        form = MedicalRecordForm()
    return render(request, 'predictor/medical_record_form.html', {'form': form, 'patient': patient})


# ------------------------------
# Prediction & Result Views
# ------------------------------

@login_required
def prediction_result(request, prediction_id):
    """
    Show detailed prediction result with comprehensive recommendation plan.
    Uses RecommendationSystem for lifestyle, diet, and medical follow‑up.
    """
    prediction = get_object_or_404(PredictionHistory, id=prediction_id)
    # Generate full plan using the recommendation system
    plan = RecommendationSystem.generate_full_plan(prediction.patient.id, prediction.id)
    context = {
        'prediction': prediction,
        'plan': plan,
        'risk_percent': round(prediction.ml_risk_score * 100, 1),
    }
    return render(request, 'predictor/result.html', context)


@login_required
def predict_page(request):
    """Page to select a patient and start a new prediction."""
    patients = Patient.objects.all().order_by('first_name')
    return render(request, 'predictor/predict.html', {'patients': patients})


# ------------------------------
# Analytics Dashboard (Enhanced)
# ------------------------------

@login_required
def analytics_dashboard(request):
    """
    Detailed analytics dashboard using both legacy and new AnalyticsEngine.
    """
    # Legacy stats (cohort‑independent)
    stats = get_cohort_stats()

    # Enhanced stats from AnalyticsEngine
    risk_distribution = AnalyticsEngine.get_risk_distribution()
    monthly_trends = AnalyticsEngine.get_monthly_trends(months=12)
    top_risk_factors = AnalyticsEngine.get_top_risk_factors()
    engagement = AnalyticsEngine.get_patient_engagement_metrics()

    # Also compute monthly risk average for chart (legacy style)
    monthly_risk = PredictionHistory.objects.annotate(
        month=TruncMonth('prediction_date')
    ).values('month').annotate(
        avg_risk=Avg('ml_risk_score'),
        count=Count('id')
    ).order_by('month')

    chart_b64 = generate_risk_distribution_chart()

    context = {
        'stats': stats,
        'risk_distribution': risk_distribution,
        'monthly_trends': monthly_trends,
        'top_risk_factors': top_risk_factors,
        'engagement_metrics': engagement,
        'monthly_risk': list(monthly_risk),
        'chart_b64': chart_b64,
    }
    return render(request, 'predictor/analytics.html', context)


# ------------------------------
# ECG Analysis View
# ------------------------------

@login_required
def upload_ecg(request, patient_pk):
    """
    Handle ECG image upload and return analysis.
    """
    patient = get_object_or_404(Patient, pk=patient_pk)
    if request.method == 'POST' and request.FILES.get('ecg_image'):
        ecg_file = request.FILES['ecg_image']
        analysis = ECGAnalysis.parse_ecg_image(ecg_file)
        # You could store the analysis result in a database model
        return JsonResponse({'success': True, 'analysis': analysis})
    return render(request, 'predictor/upload_ecg.html', {'patient': patient})


# ------------------------------
# Reporting & Export
# ------------------------------

@login_required
def generate_report(request, prediction_id):
    """Generate PDF report for a prediction."""
    prediction = get_object_or_404(PredictionHistory, id=prediction_id)
    pdf = generate_pdf_report(prediction)
    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="report_{prediction_id}.pdf"'
    return response


@login_required
def export_predictions(request):
    """Export predictions to CSV/Excel."""
    format_type = request.GET.get('format', 'csv')
    predictions = PredictionHistory.objects.filter(patient__user=request.user).order_by('-prediction_date')

    if format_type == 'csv':
        response = export_predictions_to_csv(predictions)
    elif format_type == 'excel':
        response = export_predictions_to_excel(predictions)
    else:
        messages.error(request, 'Unsupported export format')
        return redirect('predictor:patient_list')
    return response


# ------------------------------
# History View
# ------------------------------

@login_required
def prediction_history(request):
    """Show all predictions for the logged-in user."""
    predictions = PredictionHistory.objects.filter(patient__user=request.user).order_by('-prediction_date')
    paginator = Paginator(predictions, 20)
    page = request.GET.get('page')
    predictions_page = paginator.get_page(page)
    return render(request, 'predictor/history.html', {'predictions': predictions_page})


# ------------------------------
# Search & Comparison Endpoints
# ------------------------------

@login_required
def search_patients_api(request):
    """AJAX endpoint for patient search."""
    query = request.GET.get('q', '')
    patients = Patient.objects.filter(
        Q(first_name__icontains=query) |
        Q(last_name__icontains=query) |
        Q(phone__icontains=query)
    )[:10]
    results = [{'id': p.id, 'name': f"{p.first_name} {p.last_name}", 'age': p.age} for p in patients]
    return JsonResponse(results, safe=False)


@login_required
def compare_patients(request, patient_id1, patient_id2):
    """Compare two patients using ComparisonEngine."""
    from .comparison_engine import ComparisonEngine  # lazy import
    comparison = ComparisonEngine.compare_patients(patient_id1, patient_id2)
    return JsonResponse(comparison)


# ------------------------------
# Optional: Notification Settings View
# ------------------------------

@login_required
def notification_settings(request):
    """View to manage user notification preferences."""
    user = request.user
    # Add logic to save/update preferences (requires a UserProfile model)
    return render(request, 'predictor/notification_settings.html')