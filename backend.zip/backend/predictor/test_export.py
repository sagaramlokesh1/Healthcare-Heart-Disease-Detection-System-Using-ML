from analytics import PredictionAnalytics
from csv_export import CSVExporter

actual = ["A", "B", "A"]
predicted = ["A", "B", "C"]

summary = PredictionAnalytics.summary(
    actual,
    predicted,
)

print(summary)

csv_data = CSVExporter.export(
    ["Actual", "Predicted"],
    list(zip(actual, predicted)),
)

print(csv_data)