"""
Custom validators for the predictor app.
"""
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
from datetime import date, timedelta
import re


def validate_sales_date(value: date) -> None:
    """Validate sales date is not in the future."""
    if value > date.today():
        raise ValidationError("Sales date cannot be in the future.")


def validate_positive_decimal(value: float) -> None:
    """Validate value is positive decimal."""
    if value <= 0:
        raise ValidationError("Value must be positive.")


def validate_discount_range(value: float) -> None:
    """Validate discount is between 0 and 1."""
    if not 0 <= value <= 1:
        raise ValidationError("Discount must be between 0 and 1.")


def validate_sku_format(value: str) -> None:
    """Validate SKU format (alphanumeric, 3-50 chars)."""
    sku_regex = RegexValidator(
        regex=r'^[A-Z0-9-]{3,50}$',
        message="SKU must be 3-50 alphanumeric characters or hyphens (uppercase only)."
    )
    return sku_regex(value)


def validate_historical_data_sequence(dates: list[date], product_id: int) -> None:
    """Validate historical data has no gaps longer than 30 days."""
    if len(dates) < 2:
        return
    
    dates.sort()
    max_gap = timedelta(days=30)
    
    for i in range(1, len(dates)):
        gap = dates[i] - dates[i-1]
        if gap > max_gap:
            raise ValidationError(
                f"Gap between {dates[i-1].isoformat()} and {dates[i].isoformat()} "
                f"exceeds 30 days. Fill missing dates or use shorter gap."
            )


def validate_prediction_horizon(days_ahead: int) -> None:
    """Validate prediction horizon is reasonable (1-365 days)."""
    if not 1 <= days_ahead <= 365:
        raise ValidationError("Prediction horizon must be between 1 and 365 days.")