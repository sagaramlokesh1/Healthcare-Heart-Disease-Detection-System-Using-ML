"""
URL configuration for the predictor app.
"""
from django.urls import path
from . import views

app_name = 'predictor'

urlpatterns = [
    # Products
    path('products/', views.ProductListView.as_view(), name='product_list'),
    path('products/add/', views.add_product, name='add_product'),
    path('products/<int:pk>/', views.ProductDetailView.as_view(), name='product_detail'),
    
    # Predictions
    path('predict/', views.predict_sales, name='predict_sales'),
    path('predictions/', views.prediction_list, name='prediction_list'),
    path('predictions/<uuid:pk>/', views.PredictionDetailView.as_view(), name='prediction_detail'),
    
    # Dashboard & Analytics
    path('dashboard/', views.dashboard, name='dashboard'),
    
    # Exports
    path('export/', views.export_predictions, name='export_predictions'),
    
    # Categories
    path('categories/', views.CategoryListView.as_view(), name='category_list'),
    path('categories/add/', views.add_category, name='add_category'),
]