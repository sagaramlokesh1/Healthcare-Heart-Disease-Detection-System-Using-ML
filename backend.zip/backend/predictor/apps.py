"""
Predictor app configuration.
"""
from django.apps import AppConfig
import logging


class PredictorConfig(AppConfig):
    """Predictor app configuration."""
    
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'predictor'
    verbose_name = "Sales Predictor"
    
    def ready(self):
        """App ready callback."""
        import predictor.signals  # Import signals
        logger = logging.getLogger(__name__)
        logger.info("Sales Predictor app ready")