"""
Django forms for the predictor app with validation.
"""
from django import forms
from django.core.exceptions import ValidationError
from .models import Product, HistoricalSales, ProductCategory


class ProductForm(forms.ModelForm):
    """Form for creating/editing products."""
    class Meta:
        model = Product
        fields = ['name', 'category', 'sku', 'base_price']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'sku': forms.TextInput(attrs={'class': 'form-control'}),
            'base_price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
        }

    def clean_sku(self):
        sku = self.cleaned_data['sku'].upper().strip()
        if Product.objects.filter(sku=sku).exclude(pk=self.instance.pk).exists():
            raise ValidationError("SKU must be unique.")
        return sku

    def clean_base_price(self):
        price = self.cleaned_data['base_price']
        if price <= 0:
            raise ValidationError("Base price must be greater than 0.")
        return price


class HistoricalSalesForm(forms.ModelForm):
    """Form for bulk historical sales upload."""
    class Meta:
        model = HistoricalSales
        fields = ['product', 'date', 'units_sold', 'revenue', 'promotional_discount']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'units_sold': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'revenue': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'min': 0}),
            'promotional_discount': forms.NumberInput(attrs={
                'class': 'form-control', 
                'step': '0.01', 
                'min': 0, 
                'max': 1
            }),
        }

    def clean(self):
        cleaned_data = super().clean()
        units_sold = cleaned_data.get('units_sold')
        revenue = cleaned_data.get('revenue')
        discount = cleaned_data.get('promotional_discount', 0)

        if units_sold and revenue and units_sold > 0:
            avg_price = revenue / units_sold
            if avg_price <= 0:
                raise ValidationError("Average price per unit cannot be zero or negative.")

        if discount and (discount < 0 or discount > 1):
            raise ValidationError("Discount must be between 0 and 1.")

        return cleaned_data


class ProductCategoryForm(forms.ModelForm):
    """Form for product categories."""
    class Meta:
        model = ProductCategory
        fields = ['name', 'description']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }

    def clean_name(self):
        name = self.cleaned_data['name'].strip()
        if ProductCategory.objects.filter(name__iexact=name).exclude(pk=self.instance.pk).exists():
            raise ValidationError("Category name must be unique.")
        return name