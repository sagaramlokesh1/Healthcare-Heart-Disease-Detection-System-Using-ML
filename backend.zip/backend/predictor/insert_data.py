import sqlite3
import random
from datetime import datetime

DB_PATH = 'instance/medpredict.db'   # change to your database path

def insert_sample_data():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Check if table exists
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='predictions'")
    if not cursor.fetchone():
        print("❌ Table 'predictions' does not exist.")
        return
    
    # Get column names to adapt
    cursor.execute("PRAGMA table_info(predictions)")
    columns = [col[1] for col in cursor.fetchall()]
    print("📋 Columns:", columns)
    
    # We'll insert 30 random rows
    for _ in range(30):
        # Build a dictionary of values based on existing columns
        values = {}
        if 'patient_id' in columns:
            values['patient_id'] = random.randint(1, 10)
        if 'risk_level' in columns:
            values['risk_level'] = random.choice(['High', 'Medium', 'Low'])
        if 'probability' in columns:
            values['probability'] = round(random.uniform(10, 95), 1)
        if 'smoker' in columns:
            values['smoker'] = random.choice([0, 1])
        if 'diabetic' in columns:
            values['diabetic'] = random.choice([0, 1])
        if 'family_history' in columns:
            values['family_history'] = random.choice([0, 1])
        if 'hypertension' in columns:
            values['hypertension'] = random.choice([0, 1])
        if 'created_at' in columns:
            values['created_at'] = datetime.now().isoformat()
        
        # Build INSERT statement
        cols = ', '.join(values.keys())
        placeholders = ', '.join(['?' for _ in values])
        sql = f"INSERT INTO predictions ({cols}) VALUES ({placeholders})"
        cursor.execute(sql, list(values.values()))
    
    conn.commit()
    conn.close()
    print(f"✅ Inserted 30 rows into predictions.")

if __name__ == '__main__':
    insert_sample_data()