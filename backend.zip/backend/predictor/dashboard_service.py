from django.db.models import Count, Avg
from datetime import timedelta
from django.utils import timezone
from .models import Patient, Visit, PredictionHistory

class DashboardService:
    """Provide aggregated statistics and charts for the main dashboard."""

    @staticmethod
    def get_core_stats():
        """Return counts of patients, visits, high‑risk predictions."""
        total_patients = Patient.objects.count()
        total_visits = Visit.objects.count()
        high_risk = PredictionHistory.objects.filter(ml_risk_class=1).count()
        return {
            'total_patients': total_patients,
            'total_visits': total_visits,
            'high_risk_count': high_risk,
        }

    @staticmethod
    def get_recent_high_risk_patients(limit=5):
        """List of patients with latest high risk."""
        high_risk_predictions = PredictionHistory.objects.filter(ml_risk_class=1).order_by('-prediction_date')[:limit]
        results = []
        for pred in high_risk_predictions:
            results.append({
                'patient_name': f"{pred.patient.first_name} {pred.patient.last_name}",
                'risk_score': pred.ml_risk_score,
                'date': pred.prediction_date,
            })
        return results

    @staticmethod
    def get_weekly_risk_trend():
        """Average risk per day over last 7 days."""
        now = timezone.now()
        week_ago = now - timedelta(days=7)
        predictions = PredictionHistory.objects.filter(prediction_date__gte=week_ago)
        trend = {}
        for pred in predictions:
            day = pred.prediction_date.date()
            trend.setdefault(day, []).append(pred.ml_risk_score)
        return {str(day): sum(scores)/len(scores) for day, scores in trend.items()}

    @staticmethod
    def get_risk_distribution():
        """Count of patients by risk category (Low <0.3, Medium 0.3-0.6, High >0.6)."""
        low = PredictionHistory.objects.filter(ml_risk_score__lt=0.3).count()
        medium = PredictionHistory.objects.filter(ml_risk_score__gte=0.3, ml_risk_score__lt=0.6).count()
        high = PredictionHistory.objects.filter(ml_risk_score__gte=0.6).count()
        return {'Low': low, 'Medium': medium, 'High': high}