"""
PDF report generator using ReportLab.
"""
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from io import BytesIO
from datetime import date
from typing import List
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')

from .models import SalesPrediction


def generate_pdf_report(predictions: List[SalesPrediction], filename: str = None) -> bytes:
    """
    Generate comprehensive PDF sales prediction report.
    
    Args:
        predictions: List of SalesPrediction objects
        filename: Optional filename
        
    Returns:
        PDF bytes
    """
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        rightMargin=72, leftMargin=72,
        topMargin=72, bottomMargin=18
    )
    
    styles = getSampleStyleSheet()
    story = []
    
    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Title'],
        fontSize=24,
        spaceAfter=30,
        alignment=TA_CENTER
    )
    story.append(Paragraph("Sales Prediction Report", title_style))
    story.append(Spacer(1, 12))
    
    # Report date
    date_para = Paragraph(
        f"Generated: {date.today().strftime('%B %d, %Y')}",
        styles['Normal']
    )
    story.append(date_para)
    story.append(Spacer(1, 24))
    
    # Summary table
    summary_data = [['Metric', 'Value']]
    total_revenue = sum(p.predicted_revenue for p in predictions)
    avg_confidence = sum(p.confidence_score for p in predictions) / len(predictions)
    
    summary_data.extend([
        ['Total Predictions', str(len(predictions))],
        ['Total Predicted Revenue', f"${total_revenue:,.2f}"],
        ['Avg Confidence Score', f"{avg_confidence:.1%}"],
        ['High Confidence (85%+)', str(sum(1 for p in predictions if p.confidence_score >= 0.85))]
    ])
    
    summary_table = Table(summary_data)
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 14),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 24))
    
    # Predictions table
    pred_data = [['Product', 'Date', 'Units', 'Revenue', 'Confidence']]
    for pred in predictions[:20]:  # Top 20
        pred_data.append([
            pred.product.name[:30],
            pred.prediction_date.strftime('%m/%d'),
            f"{pred.predicted_units:,.0f}",
            f"${pred.predicted_revenue:,.0f}",
            f"{pred.confidence_score:.1%}"
        ])
    
    pred_table = Table(pred_data, colWidths=[2*inch, 0.8*inch, 0.8*inch, 1*inch, 0.8*inch])
    pred_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey])
    ]))
    story.append(pred_table)
    
    # Generate chart
    chart_buffer = _generate_summary_chart(predictions)
    chart_img = Image(chart_buffer, width=6*inch, height=4*inch)
    story.append(Spacer(1, 12))
    story.append(chart_img)
    
    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()


def _generate_summary_chart(predictions: List[SalesPrediction]) -> BytesIO:
    """Generate matplotlib chart for PDF."""
    fig, ax = plt.subplots(figsize=(8, 5))
    
    categories = [p.product.name[:15] for p in predictions[:10]]
    revenues = [p.predicted_revenue for p in predictions[:10]]
    
    bars = ax.bar(categories, revenues, color='#1f77b4')
    ax.set_ylabel('Predicted Revenue ($)')
    ax.set_title('Top 10 Product Revenue Predictions')
    ax.tick_params(axis='x', rotation=45)
    
    # Add value labels on bars
    for bar, revenue in zip(bars, revenues):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'${revenue:,.0f}', ha='center', va='bottom')
    
    plt.tight_layout()
    
    buffer = BytesIO()
    plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
    buffer.seek(0)
    plt.close()
    return buffer