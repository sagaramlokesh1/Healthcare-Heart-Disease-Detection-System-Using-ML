"""
Chart generation utilities using Plotly.
"""
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from typing import List, Dict, Any
from datetime import date, timedelta
from .models import SalesPrediction, HistoricalSales


def generate_sales_comparison_chart(product_id: int, days_back: int = 90) -> Dict[str, Any]:
    """
    Generate interactive sales vs prediction comparison chart.
    
    Args:
        product_id: Product ID
        days_back: Days of historical data
        
    Returns:
        Plotly JSON config
    """
    cutoff = date.today() - timedelta(days=days_back)
    
    # Historical sales
    historical = HistoricalSales.objects.filter(
        product_id=product_id,
        date__gte=cutoff
    ).order_by('date').values('date', 'units_sold', 'revenue')
    
    # Predictions
    predictions = SalesPrediction.objects.filter(
        product_id=product_id,
        prediction_date__gte=cutoff
    ).order_by('prediction_date').values('prediction_date', 'predicted_units', 'predicted_revenue')
    
    # Create DataFrame
    df_historical = pd.DataFrame(historical)
    df_predictions = pd.DataFrame(predictions)
    
    if df_historical.empty:
        return _empty_chart()
    
    fig = go.Figure()
    
    # Historical data
    fig.add_trace(go.Scatter(
        x=pd.to_datetime(df_historical['date']),
        y=df_historical['units_sold'],
        mode='lines+markers',
        name='Actual Sales',
        line=dict(color='#1f77b4', width=3),
        marker=dict(size=6)
    ))
    
    # Predictions
    if not df_predictions.empty:
        fig.add_trace(go.Scatter(
            x=pd.to_datetime(df_predictions['prediction_date']),
            y=df_predictions['predicted_units'],
            mode='lines+markers',
            name='Predictions',
            line=dict(color='#ff7f0e', width=3, dash='dash'),
            marker=dict(size=8, symbol='diamond')
        ))
    
    fig.update_layout(
        title=f'Sales vs Predictions - Last {days_back} Days',
        xaxis_title='Date',
        yaxis_title='Units Sold',
        hovermode='x unified',
        template='plotly_white',
        height=500
    )
    
    return fig.to_json()


def generate_confidence_heatmap(predictions: List[SalesPrediction]) -> Dict[str, Any]:
    """Generate confidence score heatmap."""
    df = pd.DataFrame([{
        'Product': p.product.name[:20],
        'Confidence': p.confidence_score,
        'Revenue': p.predicted_revenue,
        'Date': p.prediction_date.strftime('%m/%d')
    } for p in predictions[:50]])
    
    fig = px.density_heatmap(
        df, x='Product', y='Date',
        z='Confidence',
        color_continuous_scale='RdYlGn',
        title='Prediction Confidence Heatmap'
    )
    
    fig.update_layout(height=600)
    return fig.to_json()


def generate_revenue_forecast_chart(predictions: List[SalesPrediction]) -> Dict[str, Any]:
    """Generate revenue forecast bar chart."""
    df = pd.DataFrame([{
        'Date': p.prediction_date.strftime('%Y-%m-%d'),
        'Revenue': p.predicted_revenue,
        'Product': p.product.name[:15]
    } for p in predictions[:20]])
    
    fig = px.bar(df, x='Date', y='Revenue', color='Product',
                title='Upcoming Revenue Forecast',
                color_discrete_sequence=['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728'])
    
    fig.update_layout(height=500)
    return fig.to_json()


def _empty_chart() -> Dict[str, Any]:
    """Return empty chart configuration."""
    fig = go.Figure()
    fig.add_annotation(
        text="No data available",
        xref="paper", yref="paper",
        x=0.5, y=0.5, showarrow=False,
        font=dict(size=20)
    )
    fig.update_layout(title="No Data Available")
    return fig.to_json()