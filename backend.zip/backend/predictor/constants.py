"""
Application constants and configuration.
"""
from enum import Enum
from typing import Dict, List, Tuple
from datetime import timedelta

# Prediction settings
PREDICTION_HORIZONS = [7, 14, 30, 90]  # Days ahead options
MIN_HISTORICAL_DATA = 30  # Minimum records needed
CONFIDENCE_THRESHOLDS = {
    'low': 0.5,
    'medium': 0.7,
    'high': 0.85
}

# File export settings
CSV_EXPORT_FIELDS = [
    'product__name', 'product__sku', 'prediction_date', 
    'predicted_units', 'predicted_revenue', 'confidence_score'
]
EXCEL_SHEET_NAME = "Sales Predictions"

# Chart colors
CHART_COLORS = {
    'actual': '#1f77b4',
    'predicted': '#ff7f0e',
    'confidence_low': '#d62728',
    'confidence_high': '#2ca02c'
}

# Analytics metrics
ANALYTICS_METRICS = [
    'total_predictions',
    'avg_confidence',
    'prediction_accuracy',
    'total_predicted_revenue'
]

# Date formats
DATE_FORMATS = {
    'display': '%Y-%m-%d',
    'filename': '%Y%m%d',
    'chart': '%m/%d'
}

# File size limits (MB)
FILE_SIZE_LIMITS = {
    'csv': 10,
    'excel': 50
}

class PredictionStatus(Enum):
    """Prediction status enum."""
    PENDING = 'pending'
    COMPLETED = 'completed'
    FAILED = 'failed'

class ExportFormat(Enum):
    """Export format enum."""
    CSV = 'csv'
    EXCEL = 'xlsx'
    PDF = 'pdf'

# Default model parameters
MODEL_PARAMS = {
    'n_estimators': 100,
    'max_depth': 10,
    'random_state': 42
}