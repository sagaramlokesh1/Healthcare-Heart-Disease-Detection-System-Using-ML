from django.contrib import admin
from django.utils.html import format_html
from .models import Patient, Prediction, PredictionLog


@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin):
    list_display = ['id_short', 'age_sex', 'chest_pain_type', 'created_by', 'created_at', 'latest_prediction']
    list_filter = ['sex', 'chest_pain_type', 'resting_ecg', 'created_at']
    search_fields = ['id', 'age', 'created_by__username']
    readonly_fields = ['id']
    
    def id_short(self, obj):
        return obj.id[:8]
    id_short.short_description = 'ID'
    
    def age_sex(self, obj):
        return f"{obj.age}yo {obj.get_sex_display()}"
    age_sex.short_description = 'Demographics'
    
    def latest_prediction(self, obj):
        pred = obj.prediction_result
        if pred:
            color = 'green' if pred.prediction == 0 else 'red'
            return format_html(
                '<span style=\"color: {}; font-weight: bold;\">{}</span>',
                color, pred.get_prediction_display()
            )
        return 'No Prediction'
    latest_prediction.short_description = 'Latest Result'


@admin.register(Prediction)
class PredictionAdmin(admin.ModelAdmin):
    list_display = ['patient_link', 'prediction_badge', 'risk_level_badge', 'disease_probability', 'created_by', 'created_at']
    list_filter = ['prediction', 'risk_level', 'model_version', 'created_at']
    search_fields = ['patient__id', 'patient__age']
    
    def patient_link(self, obj):
        return f"{obj.patient.age}yo {obj.patient.get_sex_display()} ({obj.patient.id[:8]})"
    patient_link.short_description = 'Patient'
    
    def prediction_badge(self, obj):
        color = 'success' if obj.prediction == 0 else 'danger'
        return format_html(
            '<span class=\"badge badge-{} bg-{}\">{}</span>',
            color, color, obj.get_prediction_display()
        )
    prediction_badge.short_description = 'Result'
    
    def risk_level_badge(self, obj):
        colors = {'LOW': 'success', 'MEDIUM': 'warning', 'HIGH': 'danger'}
        color = colors.get(obj.risk_level, 'secondary')
        return format_html(
            '<span class=\"badge badge-{0} bg-{0}\">{1}</span>',
            color, obj.get_risk_level_display()
        )
    risk_level_badge.short_description = 'Risk'


@admin.register(PredictionLog)
class PredictionLogAdmin(admin.ModelAdmin):
    list_display = ['prediction', 'ip_address', 'response_time_ms', 'created_at']
    list_filter = ['created_at', 'response_time_ms']
    date_hierarchy = 'created_at'