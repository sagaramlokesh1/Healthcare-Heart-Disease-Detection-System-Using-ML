from django.core.mail import send_mail
from django.conf import settings

class NotificationManager:
    """Handle user notifications for reminders, high‑risk alerts, etc."""

    @staticmethod
    def send_email_notification(recipient_email, subject, message):
        """Send email via Django's mail backend."""
        try:
            send_mail(
                subject,
                message,
                settings.DEFAULT_FROM_EMAIL,
                [recipient_email],
                fail_silently=False,
            )
            return True
        except Exception:
            return False

    @staticmethod
    def send_high_risk_alert(patient, risk_score):
        """Alert patient and doctor if risk is very high."""
        if risk_score > 0.8:
            subject = "URGENT: High Heart Disease Risk Detected"
            message = f"Dear {patient.first_name}, your latest risk assessment shows a high probability. Please contact your cardiologist immediately."
            NotificationManager.send_email_notification(patient.email, subject, message)
            # Also log or trigger SMS
            return True
        return False

    @staticmethod
    def send_appointment_reminder(appointment):
        """Remind patient 24h before appointment."""
        subject = "Appointment Reminder"
        message = f"Reminder: You have an appointment with Dr. {appointment['doctor']} on {appointment['date']}."
        # In real implementation, fetch patient email from appointment
        return True