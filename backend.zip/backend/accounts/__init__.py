"""
Custom user authentication app.
"""
default_app_config = 'accounts.apps.AccountsConfig'