"""
Authentication utilities for the accounts app.
"""
import hashlib
import time
from django.core.cache import cache
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.conf import settings

class LoginThrottle:
    """Prevent brute‑force login attempts."""
    
    def __init__(self, max_attempts=5, block_duration=300):
        self.max_attempts = max_attempts
        self.block_duration = block_duration  # seconds
    
    def get_cache_key(self, username, ip_address):
        return f"login_attempts_{username}_{ip_address}"
    
    def is_blocked(self, username, ip_address):
        key = self.get_cache_key(username, ip_address)
        attempts = cache.get(key, 0)
        return attempts >= self.max_attempts
    
    def record_failure(self, username, ip_address):
        key = self.get_cache_key(username, ip_address)
        attempts = cache.get(key, 0) + 1
        cache.set(key, attempts, self.block_duration)
        return attempts
    
    def reset_attempts(self, username, ip_address):
        cache.delete(self.get_cache_key(username, ip_address))


def authenticate_user(request, username, password):
    """Authenticate user with throttling support."""
    ip = request.META.get('REMOTE_ADDR')
    throttle = LoginThrottle()
    
    if throttle.is_blocked(username, ip):
        return None, "Too many login attempts. Please try again later."
    
    user = authenticate(request, username=username, password=password)
    if user is not None and user.is_active:
        throttle.reset_attempts(username, ip)
        return user, None
    else:
        attempts = throttle.record_failure(username, ip)
        remaining = throttle.max_attempts - attempts
        return None, f"Invalid credentials. {remaining} attempts remaining."
    

def get_client_ip(request):
    """Extract real client IP (respects proxies)."""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip


def create_user_session(request, user):
    """Set custom session variables after login."""
    login(request, user)
    request.session['user_type'] = 'patient'  # could be 'doctor', 'admin'
    request.session['user_name'] = user.get_full_name() or user.username
    # Log user login time
    request.session['login_time'] = time.time()


def logout_user(request):
    """Clear session and logout."""
    logout(request)
    request.session.flush()