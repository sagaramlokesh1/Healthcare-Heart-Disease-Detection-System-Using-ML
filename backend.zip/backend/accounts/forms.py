from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, UsernameField
from django.contrib.auth import password_validation
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
from .models import User
import re


class EmailField(UsernameField):
    default_error_messages = {
        'required': _('Email is required.'),
        'invalid': _('Enter a valid email address.'),
    }


class CustomUserCreationForm(UserCreationForm):
    """
    Form for creating new users with email authentication.
    Includes password strength validation.
    """
    
    password1 = forms.CharField(
        label=_("Password"),
        strip=False,
        widget=forms.PasswordInput(attrs={'autocomplete': 'new-password', 'class': 'form-control'}),
        help_text=password_validation.password_validators_help_text_html(),
    )
    password2 = forms.CharField(
        label=_("Password confirmation"),
        widget=forms.PasswordInput(attrs={'autocomplete': 'new-password', 'class': 'form-control'}),
        strip=False,
    )
    
    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email', 'password1', 'password2')
        field_classes = {'email': EmailField}
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
        }
    
    def clean_email(self):
        """
        Validate email uniqueness case-insensitively.
        """
        email = self.cleaned_data.get('email')
        if email:
            email = email.lower()
            if User.objects.filter(email__iexact=email).exists():
                raise ValidationError(
                    _('A user with that email already exists.'),
                    code='user_exists',
                )
        return email
    
    def clean_password1(self):
        """
        Enhanced password strength validation.
        """
        password1 = self.cleaned_data.get('password1')
        if password1:
            # Django's built-in validators
            password_validation.validate_password(password1)
            
            # Custom strength checks
            if len(password1) < 8:
                raise ValidationError(
                    _('Password must be at least 8 characters long.'),
                    code='password_too_short',
                )
            
            # Check for common weak patterns
            weak_patterns = [
                r'^\\d+$',  # all digits
                r'^[a-z]+$',  # all lowercase
                r'^[A-Z]+$',  # all uppercase
                r'123456', r'password', r'qwerty', r'abc123'
            ]
            
            for pattern in weak_patterns:
                if re.search(pattern, password1, re.IGNORECASE):
                    raise ValidationError(
                        _('Password is too common or weak.'),
                        code='password_too_common',
                    )
        
        return password1
    
    def save(self, commit=True):
        """
        Save the user with normalized email.
        """
        user = super().save(commit=False)
        user.email = user.email.lower()
        if commit:
            user.save()
        return user


class CustomAuthenticationForm(AuthenticationForm):
    """
    Authentication form with custom email field.
    """
    
    email = EmailField(
        label=_("Email"),
        max_length=254,
        widget=forms.EmailInput(attrs={'autofocus': True, 'class': 'form-control'}),
    )
    
    error_messages = {
        'invalid_login': _(
            "Please enter a correct email and password. Note that password is case-sensitive."
        ),
        'inactive': _("This account is inactive."),
    }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.username_field = self.fields['email']


class UserProfileForm(forms.ModelForm):
    """
    Form for updating user profile information.
    """
    
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'profile_picture']
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
        }
    
    def clean_email(self):
        """
        Ensure email uniqueness during profile update.
        """
        email = self.cleaned_data.get('email')
        if email and email != self.instance.email:
            email = email.lower()
            if User.objects.filter(email__iexact=email).exclude(pk=self.instance.pk).exists():
                raise ValidationError(_('This email is already in use.'))
        return email