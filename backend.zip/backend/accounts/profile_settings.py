"""
User profile settings and account management.
"""
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.contrib import messages
from django.shortcuts import redirect, render
from django.urls import reverse
from .forms import ProfileUpdateForm, PasswordChangeForm

class ProfileManager:
    """Handle profile updates, password changes, and account deletion."""

    @staticmethod
    def update_profile(user, data, files=None):
        """
        Update user profile fields (first_name, last_name, email, avatar, etc.).
        Returns (success, message).
        """
        form = ProfileUpdateForm(data, files, instance=user)
        if form.is_valid():
            form.save()
            return True, "Profile updated successfully."
        return False, str(form.errors)

    @staticmethod
    def change_password(user, old_password, new_password, confirm_password):
        """
        Change user password after verifying old password.
        Returns (success, message).
        """
        if not user.check_password(old_password):
            return False, "Current password is incorrect."
        if new_password != confirm_password:
            return False, "New passwords do not match."
        if len(new_password) < 8:
            return False, "Password must be at least 8 characters."
        user.set_password(new_password)
        user.save()
        return True, "Password changed successfully."

    @staticmethod
    def delete_account(user, confirm_text):
        """
        Permanently delete user account.
        Requires confirmation text = "DELETE".
        """
        if confirm_text != "DELETE":
            return False, "Type DELETE to confirm."
        user.delete()
        return True, "Account deleted."

    @staticmethod
    def update_notification_preferences(user, email_notifications=True, sms_notifications=False):
        """Store notification preferences (extend user profile or a separate model)."""
        # Example: you could create a UserSettings model or use request.session
        user.profile.email_notifications = email_notifications
        user.profile.sms_notifications = sms_notifications
        user.save()
        return True


def get_user_dashboard_context(user):
    """
    Return statistics and recent activity for the user dashboard.
    """
    from backend.predictor.models import Patient, PredictionHistory
    try:
        patient = Patient.objects.get(user=user)
    except Patient.DoesNotExist:
        patient = None
    context = {
        'username': user.username,
        'full_name': user.get_full_name(),
        'email': user.email,
        'date_joined': user.date_joined,
        'last_login': user.last_login,
    }
    if patient:
        context['recent_predictions'] = PredictionHistory.objects.filter(patient=patient).order_by('-prediction_date')[:5]
    return context