@app.route('/appointments/confirm/<int:appointment_id>', methods=['POST'])
@login_required
@role_required(['doctor', 'admin'])
def confirm_appointment(appointment_id):
    """Doctor/admin can confirm a scheduled appointment and send email to patient."""
    appointment = appointments_db.get(appointment_id)
    if not appointment:
        flash('Appointment not found.', 'error')
        return redirect(url_for('appointments'))
    
    if appointment['status'] != 'scheduled':
        flash('Only scheduled appointments can be confirmed.', 'error')
        return redirect(url_for('appointments'))
    
    # Update status
    appointment['status'] = 'confirmed'
    
    # Send confirmation email to patient
    patient_email = appointment.get('email')
    patient_name = appointment.get('patient_name')
    doctor_name = appointment.get('doctor_name')
    appointment_date = appointment.get('date')
    reason = appointment.get('reason', 'Not specified')
    
    if patient_email:
        subject = f"Appointment Confirmed – MedPredict"
        body = f"""Dear {patient_name},

Your appointment has been confirmed by the doctor.

Details:
Doctor: {doctor_name}
Date & Time: {appointment_date}
Reason: {reason}

Please arrive on time. If you need to cancel, please contact the clinic.

Thank you,
MedPredict Team
"""
        try:
            from flask_mail import Message
            mail.send(Message(subject, recipients=[patient_email], body=body))
            flash(f'Appointment confirmed. Confirmation email sent to {patient_email}.', 'success')
        except Exception as e:
            flash(f'Appointment confirmed but failed to send email: {e}', 'warning')
            print(f"Email error: {e}")
    else:
        flash('Appointment confirmed (no email address available for patient).', 'info')
    
    return redirect(url_for('appointments'))