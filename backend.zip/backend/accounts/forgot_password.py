"""
Password reset functionality (forgot password).
Uses Django's built‑in password reset framework with custom email templates.
"""
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.tokens import default_token_generator
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from django.conf import settings
from django.urls import reverse
import secrets

def send_password_reset_email(user, request):
    """Generate reset token and send email to user."""
    token = default_token_generator.make_token(user)
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    reset_link = request.build_absolute_uri(
        reverse('accounts:password_reset_confirm', kwargs={'uidb64': uid, 'token': token})
    )
    context = {
        'user': user,
        'reset_link': reset_link,
        'site_name': 'MedPredict',
    }
    subject = render_to_string('accounts/password_reset_subject.txt', context).strip()
    message = render_to_string('accounts/password_reset_email.html', context)
    send_mail(
        subject, message, settings.DEFAULT_FROM_EMAIL, [user.email],
        html_message=message, fail_silently=False
    )


def request_password_reset(email, request):
    """
    Look up user by email and trigger reset email if found.
    Returns (user_exists, email_sent)
    """
    try:
        user = User.objects.get(email=email)
    except User.DoesNotExist:
        return False, False
    send_password_reset_email(user, request)
    return True, True


def validate_reset_token(uidb64, token):
    """Check if reset token is valid and return user."""
    from django.contrib.auth.tokens import default_token_generator
    from django.utils.http import urlsafe_base64_decode
    from django.contrib.auth.models import User
    try:
        uid = urlsafe_base64_decode(uidb64).decode()
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        return None
    if default_token_generator.check_token(user, token):
        return user
    return None