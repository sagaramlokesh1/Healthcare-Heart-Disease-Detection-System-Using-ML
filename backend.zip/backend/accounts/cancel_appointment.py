@app.route('/appointments/cancel/<int:appointment_id>', methods=['POST'])
@login_required
def cancel_appointment(appointment_id):
    appointment = appointments_db.get(appointment_id)
    if not appointment:
        flash('Appointment not found.', 'error')
        return redirect(url_for('appointments'))

    user_id = session.get('user_id')
    role = session.get('role')
    is_owner = (appointment.get('patient_id') == user_id)

    # Doctors and admins can cancel any appointment (including guest ones)
    if role in ('doctor', 'admin'):
        appointment['status'] = 'cancelled'
        flash('Appointment cancelled by staff.', 'info')
        return redirect(url_for('appointments'))

    # Logged‑in patients can only cancel their own appointments
    if not is_owner:
        flash('You are not authorised to cancel this appointment.', 'error')
        return redirect(url_for('appointments'))

    # For logged‑in patients, enforce cancellation limit (by user_id)
    count = cancellation_counts.get(user_id, 0)
    if count >= CANCELLATION_LIMIT:
        flash(f'You have reached the cancellation limit of {CANCELLATION_LIMIT} times. Please contact the clinic.', 'error')
        return redirect(url_for('appointments'))

    cancellation_counts[user_id] = count + 1
    remaining = CANCELLATION_LIMIT - (count + 1)
    appointment['status'] = 'cancelled'
    flash(f'Appointment cancelled. You have {remaining} cancellation(s) remaining.', 'warning')
    return redirect(url_for('appointments'))