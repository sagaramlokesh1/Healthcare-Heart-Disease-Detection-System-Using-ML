from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.views.generic import CreateView, UpdateView, TemplateView
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .forms import CustomUserCreationForm, CustomAuthenticationForm, UserProfileForm
from .models import User
import logging

logger = logging.getLogger(__name__)


class CustomLoginView(LoginView):
    """
    Custom login view with enhanced error handling and styling.
    """
    template_name = 'accounts/login.html'
    form_class = CustomAuthenticationForm
    redirect_authenticated_user = True
    
    def get_success_url(self):
        return reverse_lazy('accounts:profile')
    
    def form_invalid(self, form):
        """
        Handle invalid login attempts with user-friendly messages.
        """
        messages.error(self.request, 'Invalid email or password. Please try again.')
        return super().form_invalid(form)


class CustomLogoutView(LogoutView):
    """
    Custom logout view with confirmation message.
    """
    next_page = reverse_lazy('accounts:login')


class UserRegistrationView(CreateView):
    """
    User registration view with complete form validation.
    """
    model = User
    form_class = CustomUserCreationForm
    template_name = 'accounts/register.html'
    success_url = reverse_lazy('accounts:login')
    
    def form_valid(self, form):
        """
        Send welcome message and log successful registration.
        """
        user = form.save()
        logger.info(f"New user registered: {user.email}")
        messages.success(
            self.request, 
            f'Welcome {user.get_full_name()}! Your account has been created successfully.'
        )
        return super().form_valid(form)
    
    def form_invalid(self, form):
        """
        Handle registration errors gracefully.
        """
        for field, errors in form.errors.items():
            for error in errors:
                messages.error(self.request, f'{form.fields[field].label}: {error}')
        return super().form_invalid(form)


class UserProfileView(LoginRequiredMixin, UpdateView):
    """
    User profile management view.
    """
    model = User
    form_class = UserProfileForm
    template_name = 'accounts/profile.html'
    success_url = reverse_lazy('accounts:profile')
    
    def get_object(self, queryset=None):
        """Get current logged-in user."""
        return self.request.user
    
    def get_context_data(self, **kwargs):
        """Add extra context to profile page."""
        context = super().get_context_data(**kwargs)
        context['user_stats'] = {
            'date_joined': self.request.user.date_joined.strftime('%Y-%m-%d'),
            'last_login': self.request.user.last_login.strftime('%Y-%m-%d %H:%M') if self.request.user.last_login else 'Never',
        }
        return context
    
    def form_valid(self, form):
        """
        Handle successful profile update.
        """
        messages.success(self.request, 'Profile updated successfully!')
        return super().form_valid(form)
    
    def form_invalid(self, form):
        """
        Handle profile update errors.
        """
        messages.error(self.request, 'Please correct the errors below.')
        return super().form_invalid(form)


@login_required
def profile_api(request):
    """
    AJAX endpoint for profile data.
    """
    if request.method == 'GET':
        user_data = {
            'id': request.user.id,
            'email': request.user.email,
            'full_name': request.user.get_full_name(),
            'first_name': request.user.first_name,
            'last_name': request.user.last_name,
            'date_joined': request.user.date_joined.isoformat(),
            'is_staff': request.user.is_staff,
            'has_profile_picture': bool(request.user.profile_picture),
        }
        return JsonResponse(user_data)
    
    return JsonResponse({'error': 'Method not allowed'}, status=405)