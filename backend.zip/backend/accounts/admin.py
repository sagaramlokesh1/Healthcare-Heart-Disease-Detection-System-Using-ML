from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.utils.translation import gettext_lazy as _
from .forms import CustomUserCreationForm, CustomUserChangeForm
from .models import User


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    """
    Custom admin interface for User model.
    """
    ordering = ['-date_joined']
    list_display = ['email', 'get_full_name', 'first_name', 'last_name', 'is_staff', 'is_active', 'date_joined']
    list_filter = ['is_staff', 'is_superuser', 'is_active', 'date_joined']
    search_fields = ['email', 'first_name', 'last_name']
    
    add_form = CustomUserCreationForm
    form = CustomUserChangeForm
    model = User
    
    fieldsets = (
        (_('Personal info'), {
            'fields': ('first_name', 'last_name', 'email', 'profile_picture')
        }),
        (_('Permissions'), {
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions'),
        }),
        (_('Important dates'), {
            'fields': ('last_login', 'date_joined'),
        }),
    )
    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'first_name', 'last_name', 'password1', 'password2'),
        }),
    )
    
    def get_full_name(self, obj):
        """
        Display full name in admin list view.
        """
        return obj.get_full_name()
    get_full_name.short_description = _('Full Name')
    
    def get_queryset(self, request):
        """
        Optimize queryset for admin performance.
        """
        qs = super().get_queryset(request)
        return qs.select_related().prefetch_related('groups')