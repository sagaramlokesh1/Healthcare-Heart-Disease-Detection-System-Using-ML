from django.apps import AppConfig

class PatientManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'backend.patient_management'
    verbose_name = 'Patient Management'