from django.contrib import admin
from .models import Patient, MedicalRecord, Visit

@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin):
    list_display = ('id', 'first_name', 'last_name', 'age', 'phone', 'email', 'created_at')
    list_filter = ('gender', 'created_at')
    search_fields = ('first_name', 'last_name', 'phone', 'email')
    readonly_fields = ('created_at',)

@admin.register(MedicalRecord)
class MedicalRecordAdmin(admin.ModelAdmin):
    list_display = ('id', 'patient', 'condition', 'diagnosed_date')
    list_filter = ('condition', 'diagnosed_date')
    search_fields = ('patient__first_name', 'patient__last_name', 'condition')

@admin.register(Visit)
class VisitAdmin(admin.ModelAdmin):
    list_display = ('id', 'patient', 'visit_date', 'systolic_bp', 'diastolic_bp', 'smoker', 'diabetic')
    list_filter = ('smoker', 'diabetic', 'visit_date')
    search_fields = ('patient__first_name', 'patient__last_name')
    readonly_fields = ('visit_date',)