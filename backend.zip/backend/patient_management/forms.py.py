from django import forms
from .models import Patient, MedicalRecord, Visit

class PatientForm(forms.ModelForm):
    class Meta:
        model = Patient
        fields = [
            'first_name', 'last_name', 'date_of_birth', 'gender',
            'phone', 'email', 'address', 'emergency_contact_name', 'emergency_contact_phone'
        ]
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}),
            'address': forms.Textarea(attrs={'rows': 3}),
        }
    
    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        if phone and not phone.isdigit():
            raise forms.ValidationError("Phone number must contain only digits.")
        return phone

class MedicalRecordForm(forms.ModelForm):
    class Meta:
        model = MedicalRecord
        fields = ['condition', 'diagnosed_date', 'notes']
        widgets = {
            'diagnosed_date': forms.DateInput(attrs={'type': 'date'}),
            'notes': forms.Textarea(attrs={'rows': 2}),
        }

class VisitForm(forms.ModelForm):
    class Meta:
        model = Visit
        fields = [
            'reason', 'systolic_bp', 'diastolic_bp', 'heart_rate',
            'cholesterol', 'hdl_cholesterol', 'ldl_cholesterol', 'triglycerides',
            'glucose', 'smoker', 'diabetic', 'family_history', 'ecg_image', 'notes'
        ]
        widgets = {
            'reason': forms.TextInput(attrs={'placeholder': 'e.g., Routine checkup, Chest pain'}),
            'notes': forms.Textarea(attrs={'rows': 2}),
        }