from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator

class Patient(models.Model):
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.SET_NULL, null=True, blank=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    phone = models.CharField(max_length=15)
    email = models.EmailField(blank=True)
    address = models.TextField(blank=True)
    emergency_contact_name = models.CharField(max_length=100, blank=True)
    emergency_contact_phone = models.CharField(max_length=15, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.first_name} {self.last_name} (ID: {self.id})"
    
    @property
    def age(self):
        from datetime import date
        today = date.today()
        return today.year - self.date_of_birth.year - ((today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day))
    
    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"

class MedicalRecord(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='medical_records')
    condition = models.CharField(max_length=200, help_text="e.g., Hypertension, Diabetes")
    diagnosed_date = models.DateField()
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-diagnosed_date']
    
    def __str__(self):
        return f"{self.patient} - {self.condition}"

class Visit(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='visits')
    visit_date = models.DateTimeField(auto_now_add=True)
    reason = models.CharField(max_length=255, blank=True)
    
    # Vital signs
    systolic_bp = models.IntegerField(validators=[MinValueValidator(80), MaxValueValidator(250)])
    diastolic_bp = models.IntegerField(validators=[MinValueValidator(40), MaxValueValidator(150)])
    heart_rate = models.IntegerField(validators=[MinValueValidator(30), MaxValueValidator(200)], null=True, blank=True)
    
    # Lab values
    cholesterol = models.IntegerField(help_text="Total cholesterol (mg/dL)")
    hdl_cholesterol = models.IntegerField(help_text="HDL cholesterol (mg/dL)", null=True, blank=True)
    ldl_cholesterol = models.IntegerField(help_text="LDL cholesterol (mg/dL)", null=True, blank=True)
    triglycerides = models.IntegerField(help_text="Triglycerides (mg/dL)", null=True, blank=True)
    glucose = models.IntegerField(help_text="Fasting blood glucose (mg/dL)")
    
    # Risk factors
    smoker = models.BooleanField(default=False)
    diabetic = models.BooleanField(default=False)
    family_history = models.BooleanField(default=False, help_text="Family history of heart disease")
    
    # Extra
    ecg_image = models.ImageField(upload_to='uploads/ecg_images/', blank=True, null=True)
    notes = models.TextField(blank=True)
    
    class Meta:
        ordering = ['-visit_date']
    
    def __str__(self):
        return f"Visit {self.id} – {self.patient} on {self.visit_date.date()}"