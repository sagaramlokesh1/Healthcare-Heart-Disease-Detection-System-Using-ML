from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q
from .models import Patient, MedicalRecord, Visit
from .forms import PatientForm, MedicalRecordForm, VisitForm

@login_required
def patient_list(request):
    query = request.GET.get('q')
    patients = Patient.objects.all()
    if query:
        patients = patients.filter(
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(phone__icontains=query) |
            Q(email__icontains=query)
        )
    paginator = Paginator(patients, 20)
    page = request.GET.get('page')
    patients_page = paginator.get_page(page)
    return render(request, 'patient_management/patient_list.html', {
        'patients': patients_page,
        'query': query
    })

@login_required
def patient_detail(request, pk):
    patient = get_object_or_404(Patient, pk=pk)
    visits = patient.visits.all()
    medical_records = patient.medical_records.all()
    return render(request, 'patient_management/patient_detail.html', {
        'patient': patient,
        'visits': visits,
        'medical_records': medical_records
    })

@login_required
def patient_create(request):
    if request.method == 'POST':
        form = PatientForm(request.POST)
        if form.is_valid():
            patient = form.save()
            messages.success(request, f'Patient {patient.full_name} created successfully.')
            return redirect('patient_management:patient_detail', pk=patient.pk)
    else:
        form = PatientForm()
    return render(request, 'patient_management/patient_form.html', {
        'form': form,
        'title': 'Add New Patient'
    })

@login_required
def patient_edit(request, pk):
    patient = get_object_or_404(Patient, pk=pk)
    if request.method == 'POST':
        form = PatientForm(request.POST, instance=patient)
        if form.is_valid():
            form.save()
            messages.success(request, 'Patient information updated.')
            return redirect('patient_management:patient_detail', pk=patient.pk)
    else:
        form = PatientForm(instance=patient)
    return render(request, 'patient_management/patient_form.html', {
        'form': form,
        'title': 'Edit Patient',
        'patient': patient
    })

@login_required
def patient_delete(request, pk):
    patient = get_object_or_404(Patient, pk=pk)
    if request.method == 'POST':
        full_name = patient.full_name
        patient.delete()
        messages.success(request, f'Patient {full_name} deleted.')
        return redirect('patient_management:patient_list')
    return render(request, 'patient_management/patient_confirm_delete.html', {'patient': patient})

@login_required
def add_medical_record(request, patient_pk):
    patient = get_object_or_404(Patient, pk=patient_pk)
    if request.method == 'POST':
        form = MedicalRecordForm(request.POST)
        if form.is_valid():
            record = form.save(commit=False)
            record.patient = patient
            record.save()
            messages.success(request, 'Medical record added.')
            return redirect('patient_management:patient_detail', pk=patient.pk)
    else:
        form = MedicalRecordForm()
    return render(request, 'patient_management/medical_record_form.html', {
        'form': form,
        'patient': patient
    })

@login_required
def add_visit(request, patient_pk):
    patient = get_object_or_404(Patient, pk=patient_pk)
    if request.method == 'POST':
        form = VisitForm(request.POST, request.FILES)
        if form.is_valid():
            visit = form.save(commit=False)
            visit.patient = patient
            visit.save()
            messages.success(request, 'Visit recorded successfully.')
            return redirect('patient_management:patient_detail', pk=patient.pk)
    else:
        form = VisitForm()
    return render(request, 'patient_management/visit_form.html', {
        'form': form,
        'patient': patient
    })

@login_required
def edit_visit(request, patient_pk, visit_pk):
    patient = get_object_or_404(Patient, pk=patient_pk)
    visit = get_object_or_404(Visit, pk=visit_pk, patient=patient)
    if request.method == 'POST':
        form = VisitForm(request.POST, request.FILES, instance=visit)
        if form.is_valid():
            form.save()
            messages.success(request, 'Visit updated.')
            return redirect('patient_management:patient_detail', pk=patient.pk)
    else:
        form = VisitForm(instance=visit)
    return render(request, 'patient_management/visit_form.html', {
        'form': form,
        'patient': patient,
        'visit': visit
    })