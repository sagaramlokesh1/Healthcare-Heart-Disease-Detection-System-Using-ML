from django.urls import path
from . import views

app_name = 'patient_management'

urlpatterns = [
    path('', views.patient_list, name='patient_list'),
    path('<int:pk>/', views.patient_detail, name='patient_detail'),
    path('create/', views.patient_create, name='patient_create'),
    path('<int:pk>/edit/', views.patient_edit, name='patient_edit'),
    path('<int:pk>/delete/', views.patient_delete, name='patient_delete'),
    path('<int:patient_pk>/add_medical_record/', views.add_medical_record, name='add_medical_record'),
    path('<int:patient_pk>/add_visit/', views.add_visit, name='add_visit'),
    path('<int:patient_pk>/visit/<int:visit_pk>/edit/', views.edit_visit, name='edit_visit'),
]