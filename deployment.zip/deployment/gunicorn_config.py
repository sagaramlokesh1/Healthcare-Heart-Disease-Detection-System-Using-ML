#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Production Gunicorn configuration for Python web application
Optimized for typical web workloads (2-4 CPU cores, moderate traffic)
"""

import multiprocessing
import os
from pathlib import Path

# Server socket
bind = "127.0.0.1:8000"  # Bind to localhost only - nginx will proxy externally
backlog = 2048

# Worker processes - (2 x $NUM_CORES) + 1 formula for optimal throughput
workers = (multiprocessing.cpu_count() * 2) + 1
worker_class = "gevent"  # Async worker class for high concurrency
worker_connections = 1000  # Max simultaneous clients per worker
threads = 4  # Threads per worker for CPU-bound tasks
max_requests = 1000  # Restart workers after N requests to prevent memory leaks
max_requests_jitter = 100  # Randomize restarts to avoid thundering herd

# Timeouts
timeout = 120  # 2 minute timeout for slow requests
graceful_timeout = 30  # Time to wait for worker to finish current request

# Process naming (useful for monitoring)
proc_name = "python-web-app"

# Logging
accesslog = "-"  # Log to stdout (captured by container orchestration)
errorlog = "-"   # Log to stderr
loglevel = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'

# PID file for process management
pidfile = "/tmp/gunicorn.pid"
user = "www-data"  # Run as non-root user
group = "www-data"
tmp_upload_dir = None

# Security
limit_request_line = 4094  # Max header line length
limit_request_fields = 400  # Max number of headers

# Preload application code before forking workers (reduces memory usage)
preload_app = True

# Keepalive for backend connections
keepalive = 2

print(f"Starting Gunicorn with {workers} workers, {threads} threads each")