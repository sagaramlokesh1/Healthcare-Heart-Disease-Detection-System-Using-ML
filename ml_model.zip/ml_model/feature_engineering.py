class HeartFeatureEngineer:
    def create_features(self, df):
        feature_cols = df.columns.drop('target')
        X = df[feature_cols]
        y = df['target']
        return X, y, list(feature_cols)
    def save_visualizations(self, df, feature_names):
        pass