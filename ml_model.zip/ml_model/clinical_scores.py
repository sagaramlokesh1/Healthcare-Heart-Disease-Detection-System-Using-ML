import math

def framingham_risk_score(age, sex, systolic_bp, total_cholesterol, hdl_cholesterol, smoker, diabetic, treated_bp=False):
    """Framingham 10-year risk for hard CHD (%)"""
    # Points for age
    if sex == 'M':
        if 20 <= age <= 34: age_pts = -9
        elif 35 <= age <= 39: age_pts = -4
        elif 40 <= age <= 44: age_pts = 0
        elif 45 <= age <= 49: age_pts = 3
        elif 50 <= age <= 54: age_pts = 6
        elif 55 <= age <= 59: age_pts = 8
        elif 60 <= age <= 64: age_pts = 10
        elif 65 <= age <= 69: age_pts = 11
        elif 70 <= age <= 74: age_pts = 12
        elif 75 <= age <= 79: age_pts = 13
        else: age_pts = 14
    else:
        if 20 <= age <= 34: age_pts = -7
        elif 35 <= age <= 39: age_pts = -3
        elif 40 <= age <= 44: age_pts = 0
        elif 45 <= age <= 49: age_pts = 3
        elif 50 <= age <= 54: age_pts = 6
        elif 55 <= age <= 59: age_pts = 8
        elif 60 <= age <= 64: age_pts = 10
        elif 65 <= age <= 69: age_pts = 12
        elif 70 <= age <= 74: age_pts = 14
        elif 75 <= age <= 79: age_pts = 16
        else: age_pts = 17

    # Total cholesterol points
    if 20 <= age <= 39:
        if total_cholesterol < 160: chol_pts = 0
        elif total_cholesterol < 200: chol_pts = 4
        elif total_cholesterol < 240: chol_pts = 7
        else: chol_pts = 9
    elif 40 <= age <= 49:
        if total_cholesterol < 160: chol_pts = 0
        elif total_cholesterol < 200: chol_pts = 3
        elif total_cholesterol < 240: chol_pts = 5
        else: chol_pts = 6
    elif 50 <= age <= 59:
        if total_cholesterol < 160: chol_pts = 0
        elif total_cholesterol < 200: chol_pts = 2
        elif total_cholesterol < 240: chol_pts = 3
        else: chol_pts = 4
    else:
        if total_cholesterol < 160: chol_pts = 0
        elif total_cholesterol < 200: chol_pts = 1
        elif total_cholesterol < 240: chol_pts = 1
        else: chol_pts = 2

    # Smoker points
    if smoker:
        if 20 <= age <= 39: smoke_pts = 8
        elif 40 <= age <= 49: smoke_pts = 5
        elif 50 <= age <= 59: smoke_pts = 3
        else: smoke_pts = 1
    else:
        smoke_pts = 0

    # HDL cholesterol points
    if hdl_cholesterol >= 60: hdl_pts = -1
    elif hdl_cholesterol >= 50: hdl_pts = 0
    else: hdl_pts = 1

    # Systolic BP points (untreated/treated)
    if systolic_bp < 120:
        bp_pts = 0 if not treated_bp else 0
    elif systolic_bp < 130:
        bp_pts = 1 if not treated_bp else 2
    elif systolic_bp < 140:
        bp_pts = 2 if not treated_bp else 3
    elif systolic_bp < 160:
        bp_pts = 3 if not treated_bp else 4
    else:
        bp_pts = 4 if not treated_bp else 5

    total_points = age_pts + chol_pts + smoke_pts + hdl_pts + bp_pts

    risk_table = {
        0: 1, 1: 1, 2: 1, 3: 1, 4: 1,
        5: 2, 6: 2, 7: 3, 8: 4, 9: 5,
        10: 6, 11: 8, 12: 10, 13: 12, 14: 16,
        15: 20, 16: 25, 17: 30, 18: 35, 19: 40,
        20: 45, 21: 50, 22: 55, 23: 60, 24: 65,
        25: 70
    }
    return risk_table.get(total_points, 70)

def ascvd_risk_score(age, sex, systolic_bp, total_cholesterol, hdl_cholesterol, smoker, diabetic, treated_bp=False, race='white'):
    """ASCVD 10-year risk estimator (simplified)"""
    # Placeholder – use full pooled cohort equations in production
    ln_age = math.log(age)
    ln_totchol = math.log(total_cholesterol)
    ln_hdl = math.log(hdl_cholesterol)
    ln_sbp = math.log(systolic_bp)
    # Dummy calculation
    risk = 0.05
    return min(risk * 100, 100)

def qrisk3_risk_score(age, sex, systolic_bp, total_cholesterol, hdl_cholesterol, smoker, diabetic,
                      family_history, atrial_fibrillation=False, rheumatoid_arthritis=False,
                      chronic_kidney_disease=False, treated_hypertension=False):
    """QRISK3 10-year risk (simplified)"""
    # Placeholder – use official QRISK3 implementation
    risk = 0.03
    if smoker: risk += 0.05
    if diabetic: risk += 0.07
    if family_history: risk += 0.04
    if systolic_bp > 140: risk += 0.03
    return min(risk * 100, 100)