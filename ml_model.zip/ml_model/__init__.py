"""
Heart Disease Prediction ML Pipeline
Complete machine learning pipeline for heart disease prediction.
"""