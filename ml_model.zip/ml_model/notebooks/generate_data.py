import pandas as pd
import random
from datetime import datetime, timedelta

def generate_large_dataset(num_patients=200):
    first_names = ['James','Mary','John','Patricia','Robert','Jennifer','Michael','Linda','William','Elizabeth',
                   'David','Barbara','Richard','Susan','Joseph','Jessica','Thomas','Sarah','Charles','Karen']
    last_names = ['Smith','Johnson','Williams','Brown','Jones','Garcia','Miller','Davis','Rodriguez','Martinez']
    smoking_opts = ['Never','Former','Current']
    genders = ['M','F']
    med_hist = ['None','Hypertension','Diabetes','Hyperlipidemia','CAD','Atrial Fibrillation','CHF','COPD']
    
    patients = []
    predictions = []
    for i in range(1, num_patients+1):
        name = f"{random.choice(first_names)} {random.choice(last_names)}"
        age = random.randint(25, 85)
        gender = random.choice(genders)
        phone = f"555-{random.randint(100,999):03d}-{random.randint(1000,9999):04d}"
        email = f"{name.lower().replace(' ', '.')}@example.com"
        smoking = random.choices(smoking_opts, weights=[0.4,0.3,0.3])[0]
        bmi = round(random.gauss(27, 5), 1)
        bmi = max(18, min(45, bmi))
        medical = random.choice(med_hist)
        risk = 0
        if age > 60: risk += 20
        elif age > 50: risk += 10
        if gender == 'M': risk += 2
        if smoking == 'Current': risk += 15
        elif smoking == 'Former': risk += 5
        if bmi > 30: risk += 10
        elif bmi > 25: risk += 5
        risk = min(max(risk, 0), 100)
        level = 'High' if risk >= 60 else ('Medium' if risk >= 30 else 'Low')
        prob = round(risk, 1)
        patients.append({
            'patient_id': i,
            'first_name': name.split()[0],
            'last_name': name.split()[-1],
            'age': age,
            'gender': gender,
            'phone': phone,
            'email': email,
            'address': f"{random.randint(100,9999)} {random.choice(['Main','Oak','Pine','Maple'])} {random.choice(['St','Ave','Rd'])}",
            'medical_history': medical,
            'smoking_status': smoking,
            'bmi': bmi
        })
        predictions.append({
            'prediction_id': 100 + i,
            'patient_id': i,
            'prediction_date': (datetime.now() - timedelta(days=random.randint(1,365))).strftime('%Y-%m-%d'),
            'ml_risk_class': 1 if level == 'High' else 0,
            'ml_risk_score': prob / 100,
            'recommendation': f'{level} risk – follow guidelines.',
            'framingham_score': round(prob * 0.2, 1),
            'ascvd_score': round(prob * 0.18, 1),
            'qrisk3_score': round(prob * 0.22, 1)
        })
    df_patients = pd.DataFrame(patients)
    df_patients.to_csv('ml_model/dataset/patient_records.csv', index=False)
    df_predictions = pd.DataFrame(predictions)
    df_predictions.to_csv('ml_model/dataset/prediction_history.csv', index=False)
    print(f"✅ Generated {num_patients} patients and predictions.")

if __name__ == '__main__':
    generate_large_dataset(200)