def plot_confusion_matrix(self):
    """Plot confusion matrix using sklearn."""
    from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
    import matplotlib.pyplot as plt
    
    cm = confusion_matrix(self.y_test, self.y_pred)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm)
    disp.plot(cmap='Blues')
    plt.title('Confusion Matrix')
    plt.savefig(self.artifacts_path / 'confusion_matrix.png', dpi=300, bbox_inches='tight')
    plt.close()
    self.logger.info("Confusion matrix saved")