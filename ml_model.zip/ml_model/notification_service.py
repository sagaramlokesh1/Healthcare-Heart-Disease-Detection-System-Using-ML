"""
Notification Service – Sends alerts for high risk, appointment reminders, and system updates.
Supports email, SMS (via Twilio placeholder), and in-app database notifications.
"""

from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth.models import User
from .models import Patient, PredictionHistory
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class NotificationService:
    """Multi‑channel notification delivery."""

    @staticmethod
    def send_email(recipient_email, subject, message, html_message=None):
        """Send email using Django's mail backend."""
        try:
            send_mail(
                subject, message, settings.DEFAULT_FROM_EMAIL,
                [recipient_email], html_message=html_message, fail_silently=False
            )
            return True
        except Exception as e:
            logger.error(f"Email failed to {recipient_email}: {e}")
            return False

    @staticmethod
    def send_sms(phone_number, message):
        """Placeholder for SMS (integrate Twilio or other provider)."""
        # Example: from twilio.rest import Client
        # client = Client(settings.TWILIO_SID, settings.TWILIO_AUTH_TOKEN)
        # client.messages.create(body=message, to=phone_number, from_=settings.TWILIO_FROM)
        logger.info(f"SMS to {phone_number}: {message}")
        return True

    @staticmethod
    def create_in_app_notification(user, title, message, link=None):
        """Create an in-app notification (requires Notification model)."""
        # If you have a Notification model, create instance.
        # For now, just log.
        logger.info(f"In-app for {user.username}: {title} - {message}")
        # Example:
        # Notification.objects.create(user=user, title=title, message=message, link=link)
        return True

    @staticmethod
    def alert_high_risk(patient_id, risk_score):
        """Notify patient and doctor when risk score > 0.7."""
        patient = Patient.objects.get(id=patient_id)
        user = patient.user
        if not user or not user.email:
            return
        if risk_score > 0.7:
            subject = "URGENT: High Heart Disease Risk Detected"
            message = f"Dear {patient.first_name}, your latest risk assessment shows a high probability ({risk_score*100:.0f}%). Please contact your cardiologist immediately."
            NotificationService.send_email(user.email, subject, message)
            NotificationService.create_in_app_notification(
                user, "High Risk Alert", message, link="/predictor/patient_detail/{}".format(patient_id)
            )
            # Also notify doctor (e.g., practice email)
            if hasattr(settings, 'DOCTOR_EMAIL'):
                NotificationService.send_email(settings.DOCTOR_EMAIL, f"High risk patient: {patient.full_name}", message)

    @staticmethod
    def send_appointment_reminder(patient_email, appointment_date, doctor_name):
        """Remind patient 24h before appointment."""
        subject = "Appointment Reminder – MedPredict"
        message = f"Reminder: You have an appointment with Dr. {doctor_name} on {appointment_date}. Please arrive 15 minutes early."
        NotificationService.send_email(patient_email, subject, message)

    @staticmethod
    def send_welcome_email(user):
        """Welcome email after registration."""
        subject = "Welcome to MedPredict"
        message = "Thank you for joining MedPredict. Start your heart health journey by adding your health data."
        NotificationService.send_email(user.email, subject, message)

    @staticmethod
    def check_and_send_weekly_summary(user):
        """Send a weekly summary of risk trends (placeholder)."""
        # Query last 7 days predictions
        week_ago = datetime.now() - timedelta(days=7)
        predictions = PredictionHistory.objects.filter(patient__user=user, prediction_date__gte=week_ago).order_by('-prediction_date')
        if predictions:
            latest = predictions.first().ml_risk_score
            avg = predictions.aggregate(avg=models.Avg('ml_risk_score'))['avg']
            subject = "Your Weekly Heart Health Summary"
            message = f"Your latest risk score: {latest*100:.0f}%. Average over last 7 days: {avg*100:.0f}%."
            NotificationService.send_email(user.email, subject, message)