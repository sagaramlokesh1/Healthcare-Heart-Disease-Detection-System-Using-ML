import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

def generate_plots(df):
    # 1. Heatmap
    plt.figure(figsize=(10, 8))
    sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
    plt.savefig('ml_model/visualizations/heatmap.png')
    
    # 2. Risk Distribution
    plt.figure(figsize=(6, 4))
    sns.countplot(x='target', data=df)
    plt.savefig('ml_model/visualizations/risk_distribution.png')
    
    print("Visualizations generated successfully!")

# Usage:
# df = pd.read_csv('ml_model/dataset/heart.csv')
# generate_plots(df)