import os

folder_path = r"C:\Users\sagar\OneDrive\Pictures\HeartDiseaseProject\ml_model\dataset"
print(f"Checking directory: {folder_path}")

if os.path.exists(folder_path):
    files = os.listdir(folder_path)
    print(f"Files found in folder: {files}")
else:
    print("The folder 'dataset' does not exist!")