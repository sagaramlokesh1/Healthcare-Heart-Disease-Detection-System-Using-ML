#!/usr/bin/env python3
"""
Main entry point to run the complete ML pipeline end-to-end.
Execute with: python run_pipeline.py
"""

import sys
import os
from pathlib import Path
import subprocess

def run_command(command: str, cwd: Path = Path(".")) -> bool:
    """Run shell command and return success status."""
    try:
        result = subprocess.run(command, shell=True, cwd=cwd, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✓ {command}")
            return True
        else:
            print(f"✗ Command failed: {command}")
            print(f"Error: {result.stderr}")
            return False
    except Exception as e:
        print(f"✗ Exception running {command}: {e}")
        return False

def main():
    print("🚀 Starting Heart Disease ML Pipeline...")
    
    # Step 1: Download dataset
    print("\n1. 📥 Downloading dataset...")
    if not run_command("python download_dataset.py"):
        sys.exit(1)
    
    # Step 2: Run ML pipeline
    ml_model_dir = Path("ml_model")
    ml_model_dir.mkdir(exist_ok=True)
    
    print("\n2. 🧠 Running ML pipeline...")
    pipeline_script = ml_model_dir / "train_model.py"
    
    if not run_command(f"python {pipeline_script}", cwd=ml_model_dir):
        sys.exit(1)
    
    print("\n3. ✅ Pipeline completed successfully!")
    print("\n📁 Generated artifacts:")
    print("   - saved_models/ (model.pkl, scaler.pkl, feature_columns.pkl)")
    print("   - reports/ (accuracy_report.txt, model_performance.pdf)")
    print("   - visualizations/ (5 PNG files)")
    
    print("\n🎉 Ready for Django integration!")

if __name__ == "__main__":
    main()