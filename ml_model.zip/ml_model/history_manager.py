"""
History Manager – Provides methods to retrieve, compare, and analyze patient history
including visits, predictions, and medical records.
"""

from django.db.models import Avg, Min, Max
from .models import Patient, Visit, PredictionHistory, MedicalRecord
from datetime import timedelta
from django.utils import timezone


class HistoryManager:
    """Handles patient longitudinal data and trend analysis."""

    @staticmethod
    def get_timeline(patient_id, start_date=None, end_date=None):
        """
        Return a chronological list of events (visits, predictions, medical records).
        """
        patient = Patient.objects.get(id=patient_id)
        visits = patient.visits.filter(visit_date__gte=start_date, visit_date__lte=end_date) if start_date else patient.visits.all()
        predictions = patient.predictions.all()
        events = []
        for v in visits:
            events.append({
                "type": "visit",
                "date": v.visit_date,
                "systolic_bp": v.systolic_bp,
                "diastolic_bp": v.diastolic_bp,
                "cholesterol": v.cholesterol,
                "glucose": v.glucose,
            })
        for p in predictions:
            events.append({
                "type": "prediction",
                "date": p.prediction_date,
                "risk_score": p.ml_risk_score,
                "risk_class": p.ml_risk_class,
            })
        # Sort by date
        events.sort(key=lambda x: x["date"])
        return events

    @staticmethod
    def get_risk_trend(patient_id, months=6):
        """
        Return list of risk scores over last N months for charting.
        """
        cutoff = timezone.now() - timedelta(days=30*months)
        predictions = PredictionHistory.objects.filter(
            patient_id=patient_id, prediction_date__gte=cutoff
        ).order_by('prediction_date')
        return [
            {"date": p.prediction_date.strftime("%Y-%m-%d"), "risk": p.ml_risk_score}
            for p in predictions
        ]

    @staticmethod
    def get_vital_signs_history(patient_id):
        """
        Return BP, cholesterol, glucose readings over time.
        """
        visits = Visit.objects.filter(patient_id=patient_id).order_by('visit_date')
        return {
            "dates": [v.visit_date.strftime("%Y-%m-%d") for v in visits],
            "systolic_bp": [v.systolic_bp for v in visits],
            "diastolic_bp": [v.diastolic_bp for v in visits],
            "cholesterol": [v.cholesterol for v in visits],
            "glucose": [v.glucose for v in visits],
        }

    @staticmethod
    def compare_time_periods(patient_id, period1_start, period1_end, period2_start, period2_end):
        """
        Compare average risk scores between two time periods.
        Returns dict with avg_risk1, avg_risk2, difference.
        """
        preds1 = PredictionHistory.objects.filter(
            patient_id=patient_id, prediction_date__range=(period1_start, period1_end)
        )
        preds2 = PredictionHistory.objects.filter(
            patient_id=patient_id, prediction_date__range=(period2_start, period2_end)
        )
        avg1 = preds1.aggregate(Avg('ml_risk_score'))['ml_risk_score__avg'] or 0
        avg2 = preds2.aggregate(Avg('ml_risk_score'))['ml_risk_score__avg'] or 0
        return {
            "period1_avg_risk": avg1,
            "period2_avg_risk": avg2,
            "difference": avg2 - avg1,
            "improved": avg2 < avg1
        }

    @staticmethod
    def get_last_medical_record(patient_id):
        """Return most recent medical record."""
        return MedicalRecord.objects.filter(patient_id=patient_id).order_by('-diagnosed_date').first()

    @staticmethod
    def get_visit_frequency(patient_id):
        """Calculate average days between visits."""
        visits = Visit.objects.filter(patient_id=patient_id).order_by('visit_date')
        if visits.count() < 2:
            return None
        diffs = [(visits[i+1].visit_date - visits[i].visit_date).days for i in range(len(visits)-1)]
        return sum(diffs) / len(diffs)