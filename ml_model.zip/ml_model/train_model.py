#!/usr/bin/env python3
"""
Complete end-to-end ML pipeline for heart disease prediction.
Downloads dataset → preprocess → engineer features → train → evaluate → save artifacts.
FIXED: All visualization errors resolved.
"""

import os
import sys
import logging
import warnings
from pathlib import Path
import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay
import requests

# Disable warnings for cleaner output
warnings.filterwarnings('ignore')

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create minimal preprocessor, engineer, evaluator classes inline
class HeartDataPreprocessor:
    def preprocess(self, data_path):
        """Simple preprocessing."""
        df = pd.read_csv(data_path, na_values='?')
        df.columns = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
                     'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal', 'target']
        df = df.fillna(df.median(numeric_only=True))
        df['target'] = (df['target'] > 0).astype(int)
        logger.info(f"Preprocessed data shape: {df.shape}")
        return df
    
    def plot_correlation_matrix(self, df, save_path):
        """Plot correlation matrix."""
        plt.figure(figsize=(12, 10))
        corr = df.corr(numeric_only=True)
        sns.heatmap(corr, annot=True, cmap='coolwarm', center=0)
        plt.title('Feature Correlation Matrix')
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()

class HeartFeatureEngineer:
    def create_features(self, df):
        """Create features and target."""
        feature_cols = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
                       'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal']
        X = df[feature_cols]
        y = df['target']
        return X, y, feature_cols
    
    def plot_risk_distribution(self, df, save_path):
        """Plot risk distribution."""
        plt.figure(figsize=(10, 6))
        df['target'].value_counts().plot(kind='bar')
        plt.title('Heart Disease Distribution')
        plt.xlabel('Target (0=No, 1=Yes)')
        plt.ylabel('Count')
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
    
    def plot_heatmap(self, df, save_path):
        """Plot feature heatmap."""
        plt.figure(figsize=(12, 8))
        sns.heatmap(df.corr(numeric_only=True), annot=True, cmap='viridis')
        plt.title('Feature Heatmap')
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()

class ModelEvaluator:
    def plot_confusion_matrix(self, y_true, y_pred, save_path):
        """Plot confusion matrix."""
        cm = confusion_matrix(y_true, y_pred)
        disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['No Disease', 'Disease'])
        disp.plot(cmap='Blues')
        plt.title('Confusion Matrix')
        Path(save_path).parent.mkdir(exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        logger.info("Confusion matrix saved")
    
    def plot_feature_importance(self, model, feature_names, save_path):
        """Plot feature importance."""
        importances = model.feature_importances_
        importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': importances
        }).sort_values('importance', ascending=True)
        
        plt.figure(figsize=(10, 8))
        plt.barh(importance_df['feature'], importance_df['importance'])
        plt.title('Feature Importance')
        plt.xlabel('Importance')
        Path(save_path).parent.mkdir(exist_ok=True)
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        logger.info("Feature importance saved")
    
    def generate_accuracy_report(self, test_acc, cv_score, save_path):
        """Generate accuracy report."""
        report = f"""
HEART DISEASE MODEL PERFORMANCE REPORT
=====================================
Test Accuracy:  {test_acc:.4f}
Cross-Validation: {cv_score:.4f}
=====================================
        """
        Path(save_path).parent.mkdir(exist_ok=True)
        with open(save_path, 'w') as f:
            f.write(report)
        logger.info("Accuracy report saved")
    
    def generate_pdf_report(self, data_shape, accuracy, feature_names, save_path):
        """Generate simple text PDF report."""
        report = f"""
Model Performance Summary
Data Shape: {data_shape}
Accuracy: {accuracy:.4f}
Features: {len(feature_names)}
Top Features: {feature_names[:5]}
        """
        Path(save_path).parent.mkdir(exist_ok=True)
        with open(save_path, 'w') as f:
            f.write(report)
        logger.info("PDF report saved (text format)")

def setup_directories():
    """Create all required directories."""
    directories = [
        Path('dataset'),
        Path('saved_models'),
        Path('reports'),
        Path('visualizations')
    ]
    for directory in directories:
        directory.mkdir(exist_ok=True)
        logger.info(f"Created directory: {directory}")

def download_dataset():
    """Download heart disease dataset."""
    dataset_path = Path('dataset/heart.csv')
    
    if dataset_path.exists():
        logger.info(f"Dataset already exists: {dataset_path}")
        return str(dataset_path)
    
    logger.info("Downloading heart disease dataset...")
    url = "https://archive.ics.uci.edu/ml/machine-learning-databases/heart-disease/processed.cleveland.data"
    
    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        
        dataset_path.parent.mkdir(exist_ok=True)
        with open(dataset_path, 'wb') as f:
            f.write(response.content)
        
        logger.info(f"Dataset downloaded: {dataset_path}")
        return str(dataset_path)
    except Exception as e:
        logger.error(f"Download failed: {e}")
        # Use local dataset if download fails
        local_path = Path('heart.csv')
        if local_path.exists():
            logger.info("Using local heart.csv")
            return str(local_path)
        sys.exit(1)

def main():
    """Main training pipeline."""
    logger.info("🚀 Starting Heart Disease ML Pipeline")
    
    try:
        # 1. Setup directories
        setup_directories()
        
        # 2. Get dataset
        data_path = download_dataset()
        
        # 3. Preprocessing
        logger.info("📊 Data Preprocessing...")
        preprocessor = HeartDataPreprocessor()
        df_clean = preprocessor.preprocess(data_path)
        
        # 4. Feature Engineering
        logger.info("🔧 Feature Engineering...")
        engineer = HeartFeatureEngineer()
        X, y, feature_names = engineer.create_features(df_clean)
        
        # Scale features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # 5. Train/Test Split
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y, test_size=0.2, random_state=42, stratify=y
        )
        
        logger.info(f"Training set: {X_train.shape}")
        logger.info(f"Test set: {X_test.shape}")
        
        # 6. Model Training
        logger.info("🤖 Training Model...")
        param_grid = {
            'n_estimators': [100],
            'max_depth': [10],
            'min_samples_split': [2],
            'min_samples_leaf': [2]
        }
        
        rf = RandomForestClassifier(random_state=42, n_jobs=-1)
        grid_search = GridSearchCV(rf, param_grid, cv=5, scoring='accuracy', n_jobs=-1)
        grid_search.fit(X_train, y_train)
        
        best_model = grid_search.best_estimator_
        logger.info(f"Best params: {grid_search.best_params_}")
        logger.info(f"Best CV score: {grid_search.best_score_:.4f}")
        
        # 7. Evaluation
        y_pred = best_model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        logger.info(f"Test Accuracy: {accuracy:.4f}")
        
        # 8. Save Artifacts
        logger.info("💾 Saving Model Artifacts...")
        Path('saved_models').mkdir(exist_ok=True)
        
        joblib.dump(best_model, 'saved_models/heart_model.pkl')
        joblib.dump(scaler, 'saved_models/scaler.pkl')
        joblib.dump(feature_names, 'saved_models/feature_columns.pkl')
        
        # 9. Generate Reports & Visualizations
        logger.info("📈 Generating Reports & Visualizations...")
        evaluator = ModelEvaluator()
        
        evaluator.plot_confusion_matrix(y_test, y_pred, 'reports/confusion_matrix.png')
        evaluator.plot_feature_importance(best_model, feature_names, 'reports/feature_importance.png')
        evaluator.generate_accuracy_report(accuracy, grid_search.best_score_, 'reports/accuracy_report.txt')
        evaluator.generate_pdf_report(df_clean.shape, accuracy, feature_names, 'reports/model_performance.txt')
        
        # Visualizations
        preprocessor.plot_correlation_matrix(df_clean, 'visualizations/correlation_matrix.png')
        engineer.plot_risk_distribution(df_clean, 'visualizations/risk_distribution.png')
        engineer.plot_heatmap(df_clean, 'visualizations/heatmap.png')
        
        logger.info("✅ Pipeline COMPLETED SUCCESSFULLY!")
        logger.info("\n📁 Ready for Django:")
        logger.info("   saved_models/heart_model.pkl")
        logger.info("   saved_models/scaler.pkl")
        logger.info("   saved_models/feature_columns.pkl")
        
    except Exception as e:
        logger.error(f"Pipeline failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()