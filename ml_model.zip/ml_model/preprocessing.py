import pandas as pd
class HeartDataPreprocessor:
    def preprocess(self, file_path):
        df = pd.read_csv(file_path)
        df = df.dropna()
        return df
    def save_correlation_heatmap(self, df, filepath):
        pass