import os
path = r"C:\Users\sagar\OneDrive\Pictures\HeartDiseaseProject\ml_model\heart.csv"
exists = os.path.isfile(path)
print(f"Does the file exist? {exists}")
if exists:
    print(f"File size: {os.path.getsize(path)} bytes")