import pandas as pd
print(f"✅ Pandas version: {pd.__version__}")
print("Pandas imported successfully!")