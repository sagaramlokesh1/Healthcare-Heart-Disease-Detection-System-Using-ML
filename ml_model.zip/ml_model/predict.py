#!/usr/bin/env python3
"""
Production prediction service for heart disease.
Loads trained model and makes real-time predictions.
Usage: python predict.py
"""

import sys
import logging
import json
import pandas as pd
import numpy as np
import joblib
from pathlib import Path
from typing import Dict, Any, Union, List
from sklearn.preprocessing import StandardScaler

# Local imports
sys.path.append(str(Path(__file__).parent))
from preprocessing import HeartDataPreprocessor
from feature_engineering import HeartFeatureEngineer

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class HeartDiseasePredictor:
    """
    Production-ready prediction service.
    
    Features:
    - Automatic model artifact loading
    - Input validation
    - Risk stratification
    - Batch prediction support
    """
    
    REQUIRED_FEATURES = [
        'age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
        'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal'
    ]
    
    def __init__(self, model_dir: str = 'saved_models'):
        """
        Initialize predictor with model loading.
        
        Raises:
            FileNotFoundError: If model artifacts missing
        """
        self.model_dir = Path(model_dir)
        self.model_path = self.model_dir / 'heart_model.pkl'
        self.scaler_path = self.model_dir / 'scaler.pkl'
        self.features_path = self.model_dir / 'feature_columns.pkl'
        
        self.model = None
        self.scaler = None
        self.feature_columns = None
        self.preprocessor = HeartDataPreprocessor()
        self.feature_engineer = HeartFeatureEngineer()
        
        self._load_artifacts()
        logger.info(f"✓ Predictor initialized: {type(self.model).__name__}")
    
    def _load_artifacts(self):
        """Load all model artifacts with validation."""
        required_files = [self.model_path, self.scaler_path, self.features_path]
        
        for file_path in required_files:
            if not file_path.exists():
                raise FileNotFoundError(
                    f"Model artifact missing: {file_path}\n"
                    f"Run 'python train_model.py' first."
                )
        
        self.model = joblib.load(self.model_path)
        self.scaler = joblib.load(self.scaler_path)
        self.feature_columns = joblib.load(self.features_path)
        
        logger.info(f"Loaded {len(self.feature_columns)} features")
    
    def _validate_patient_data(self, data: Dict[str, Any]) -> None:
        """Validate patient data format and required fields."""
        if not isinstance(data, dict):
            raise ValueError("Patient data must be a dictionary")
        
        missing = [f for f in self.REQUIRED_FEATURES if f not in data]
        if missing:
            raise ValueError(f"Missing required features: {missing}")
        
        # Type and range validation
        for feature, value in data.items():
            if not isinstance(value, (int, float)):
                raise ValueError(f"Feature '{feature}' must be numeric")
            
            # Basic medical range validation
            if feature == 'age' and (value < 20 or value > 100):
                raise ValueError("Age must be between 20-100")
    
    def _prepare_features(self, patient_data: Dict[str, Any]) -> np.ndarray:
        """Transform patient data into model-ready feature vector."""
        # Create single-row dataframe
        df_patient = pd.DataFrame([patient_data])
        
        # Apply same feature engineering as training
        X, _, _ = self.feature_engineer.create_features(df_patient)
        
        # Align with training feature columns
        X_aligned = np.zeros((1, len(self.feature_columns)))
        for i, feature in enumerate(self.feature_columns):
            if feature in patient_data:
                X_aligned[0, i] = patient_data[feature]
        
        # Scale features
        X_scaled = self.scaler.transform(X_aligned)
        return X_scaled.flatten()
    
    def predict(self, patient_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make heart disease prediction for single patient.
        
        Args:
            patient_data: Dict with patient features
            
        Returns:
            Dict with prediction, probability, risk level, and confidence
        """
        self._validate_patient_data(patient_data)
        
        try:
            # Feature preparation
            X = self._prepare_features(patient_data)
            
            # Model prediction
            prediction = self.model.predict(X.reshape(1, -1))[0]
            probability = self.model.predict_proba(X.reshape(1, -1))[0, 1]
            
            # Risk stratification
            risk_level = self._classify_risk(probability)
            confidence = max(probability, 1 - probability)
            
            result = {
                'success': True,
                'prediction': int(prediction),
                'prediction_label': 'Healthy' if prediction == 0 else 'Disease Detected',
                'disease_probability': round(float(probability), 4),
                'risk_level': risk_level,
                'confidence': round(float(confidence), 4),
                'risk_percentage': f"{probability*100:.1f}%"
            }
            
            logger.info(f"Prediction: {result['prediction_label']} "
                       f"({result['disease_probability']:.1%})")
            return result
            
        except Exception as e:
            logger.error(f"Prediction failed: {e}")
            return {'success': False, 'error': str(e)}
    
    def _classify_risk(self, probability: float) -> str:
        """Convert probability to risk level."""
        if probability < 0.30:
            return "Low Risk"
        elif probability < 0.70:
            return "Medium Risk"
        else:
            return "High Risk"
    
    def batch_predict(self, patients_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Batch prediction for multiple patients."""
        results = []
        for i, patient in enumerate(patients_data):
            result = self.predict(patient)
            result['patient_id'] = i
            results.append(result)
        return results
    
    @property
    def is_ready(self) -> bool:
        """Check if predictor is ready for production use."""
        return all(p.exists() for p in [self.model_path, self.scaler_path, self.features_path])

# Demo and testing
def run_demo():
    """Run prediction demo with sample patients."""
    if not HeartDiseasePredictor.is_ready():
        print("❌ Model not ready! Run: python train_model.py")
        return
    
    predictor = HeartDiseasePredictor()
    
    # Sample patients
    demo_patients = [
        {  # High risk patient
            'age': 65, 'sex': 1, 'cp': 3, 'trestbps': 160, 'chol': 280,
            'fbs': 1, 'restecg': 1, 'thalach': 110, 'exang': 1,
            'oldpeak': 3.0, 'slope': 1, 'ca': 2, 'thal': 2
        },
        {  # Low risk patient
            'age': 35, 'sex': 0, 'cp': 0, 'trestbps': 120, 'chol': 180,
            'fbs': 0, 'restecg': 0, 'thalach': 180, 'exang': 0,
            'oldpeak': 0.0, 'slope': 0, 'ca': 0, 'thal': 0
        }
    ]
    
    print("🎯 HEART DISEASE PREDICTION DEMO")
    print("=" * 60)
    
    for patient in demo_patients:
        result = predictor.predict(patient)
        print(f"\nPatient Age: {patient['age']}, Sex: {'M' if patient['sex'] else 'F'}")
        print(f"Prediction: {result['prediction_label']}")
        print(f"Risk: {result['risk_level']} ({result['risk_percentage']})")
        print(f"Confidence: {result['confidence']:.1%}")

if __name__ == "__main__":
    run_demo()
    