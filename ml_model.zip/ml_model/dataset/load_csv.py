import sqlite3
import csv
from datetime import datetime
import os

# ─── Find the project root ──────────────────────────────────
# This script is in: HeartDiseaseProject/ml_model/dataset/load_csv.py
# Project root is two levels up.
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(script_dir))  # goes up to HeartDiseaseProject

# ─── Look for the database ──────────────────────────────────
possible_paths = [
    os.path.join(project_root, 'instance', 'medpredict.db'),
    os.path.join(project_root, 'medpredict.db'),
    os.path.join(project_root, 'instance', 'heart.db'),
    os.path.join(project_root, 'heart.db'),
    'instance/medpredict.db',   # fallback relative to CWD
]

DB_PATH = None
for p in possible_paths:
    if os.path.exists(p):
        DB_PATH = p
        break

if DB_PATH is None:
    print("❌ Database not found automatically.")
    print(f"   Searched in: {project_root}")
    for p in possible_paths:
        print(f"     - {p}")
    user_input = input("\nPlease enter the full path to your SQLite database file: ").strip()
    if os.path.exists(user_input):
        DB_PATH = user_input
    else:
        print(f"❌ File not found: {user_input}")
        exit(1)

print(f"✅ Using database: {DB_PATH}")

# ─── CSV file location ──────────────────────────────────────
CSV_FILE = os.path.join(script_dir, 'risk_data.csv')
if not os.path.exists(CSV_FILE):
    print(f"❌ CSV file not found at: {CSV_FILE}")
    exit(1)

print(f"✅ Using CSV: {CSV_FILE}")

# ─── Connect and get table schema ──────────────────────────
conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='predictions'")
if not cursor.fetchone():
    print("❌ Table 'predictions' does not exist. Please check your database.")
    exit(1)

cursor.execute("PRAGMA table_info(predictions)")
columns_info = cursor.fetchall()
existing_columns = [col[1] for col in columns_info]
print("📋 Existing columns:", existing_columns)

# ─── Map logical names to actual column names ──────────────
# If your columns are different, adjust this dictionary.
mapping = {
    'patient_id': 'patient_id',
    'risk_level': 'risk_level',
    'probability': 'probability',
    'smoker': 'smoker',
    'diabetic': 'diabetic',
    'family_history': 'family_history',
    'hypertension': 'hypertension',
    'created_at': 'created_at'
}

# If a column doesn't exist, try common alternatives
alternatives = {
    'risk_level': ['risk', 'risk_level', 'risk_category'],
    'probability': ['probability', 'score', 'risk_score', 'prob'],
    'smoker': ['smoker', 'is_smoker', 'smoking'],
    'diabetic': ['diabetic', 'is_diabetic', 'has_diabetes'],
    'family_history': ['family_history', 'has_family_history'],
    'hypertension': ['hypertension', 'has_hypertension'],
}

# Determine which columns actually exist
actual_columns = {}
for logical, col in mapping.items():
    if col in existing_columns:
        actual_columns[logical] = col
    else:
        found = None
        for alt in alternatives.get(logical, []):
            if alt in existing_columns:
                found = alt
                break
        if found:
            actual_columns[logical] = found
        else:
            # Column not found – we'll skip it (but warn)
            print(f"⚠️ Column '{logical}' not found. It will be skipped.")
            actual_columns[logical] = None

# Remove skipped columns
actual_columns = {k: v for k, v in actual_columns.items() if v is not None}

# Ensure required columns exist
required = ['patient_id', 'risk_level', 'probability']
missing = [r for r in required if r not in actual_columns]
if missing:
    print(f"❌ Missing required columns: {missing}. Cannot proceed.")
    exit(1)

print("✅ Mapping used:", actual_columns)

# ─── Read CSV and insert ────────────────────────────────────
with open(CSV_FILE, 'r', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    rows = list(reader)
    if not rows:
        print("❌ CSV is empty.")
        exit(1)

    insert_cols = list(actual_columns.values())
    placeholders = ', '.join(['?' for _ in insert_cols])
    sql = f"INSERT INTO predictions ({', '.join(insert_cols)}) VALUES ({placeholders})"

    inserted = 0
    for row in rows:
        values = []
        for logical, col in actual_columns.items():
            if logical == 'patient_id':
                values.append(int(row['patient_id']))
            elif logical == 'risk_level':
                values.append(row['risk_level'])
            elif logical == 'probability':
                values.append(float(row['probability']))
            elif logical in ['smoker', 'diabetic', 'family_history', 'hypertension']:
                # Convert to 0/1
                val = row.get(logical, '0').strip()
                values.append(1 if val in ['1', 'True', 'true', 'Yes', 'yes'] else 0)
            elif logical == 'created_at':
                values.append(datetime.now().isoformat())
            else:
                # For any other column, take the CSV value as is
                values.append(row.get(logical, ''))
        cursor.execute(sql, values)
        inserted += 1

conn.commit()
conn.close()
print(f"✅ Inserted {inserted} rows from {CSV_FILE}.")
print("👉 Now visit /analytics to see the Risk Factors chart.")