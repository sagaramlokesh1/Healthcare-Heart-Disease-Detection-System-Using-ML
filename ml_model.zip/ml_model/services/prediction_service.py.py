"""
ML Prediction Service for Heart Disease model.
Handles model loading, prediction, and CSV generation with comprehensive error handling.
"""
import os
import logging
import pickle
import pandas as pd
import numpy as np
from typing import List, Dict, Any, Tuple
from django.core.exceptions import ValidationError
from pathlib import Path

logger = logging.getLogger(__name__)

class HeartDiseasePredictionService:
    MODEL_DIR = Path('ml_model/saved_models')
    REQUIRED_FILES = ['heart_model.pkl', 'scaler.pkl', 'feature_columns.pkl']
    
    def __init__(self):
        self.model = None
        self.scaler = None
        self.feature_columns = None
        self._is_loaded = False
    
    def load_model(self) -> bool:
        """Load all required model files with comprehensive error handling."""
        try:
            model_path = self.MODEL_DIR / 'heart_model.pkl'
            scaler_path = self.MODEL_DIR / 'scaler.pkl'
            features_path = self.MODEL_DIR / 'feature_columns.pkl'
            
            # Check if directory exists
            if not self.MODEL_DIR.exists():
                logger.error(f"Model directory not found: {self.MODEL_DIR}")
                raise FileNotFoundError(f"Model directory not found: {self.MODEL_DIR}")
            
            # Load model
            if not model_path.exists():
                logger.error(f"Model file not found: {model_path}")
                raise FileNotFoundError(f"Model file missing: {model_path}")
            
            with open(model_path, 'rb') as f:
                self.model = pickle.load(f)
            
            # Load scaler
            if not scaler_path.exists():
                logger.error(f"Scaler file not found: {scaler_path}")
                raise FileNotFoundError(f"Scaler file missing: {scaler_path}")
            
            with open(scaler_path, 'rb') as f:
                self.scaler = pickle.load(f)
            
            # Load feature columns
            if not features_path.exists():
                logger.error(f"Feature columns file not found: {features_path}")
                raise FileNotFoundError(f"Feature columns file missing: {features_path}")
            
            with open(features_path, 'rb') as f:
                self.feature_columns = pickle.load(f)
            
            self._is_loaded = True
            logger.info("Heart Disease model loaded successfully")
            return True
            
        except FileNotFoundError as e:
            logger.exception(f"Model file loading failed: {e}")
            raise
        except pickle.UnpicklingError as e:
            logger.exception(f"Model unpickling failed: {e}")
            raise ValidationError("Invalid model files. Please check model integrity.")
        except Exception as e:
            logger.exception(f"Unexpected error loading model: {e}")
            raise ValidationError("Failed to load model. Please contact administrator.")
    
    def validate_sample_data(self, sample_data: List[Dict[str, Any]]) -> Tuple[bool, str]:
        """Validate input data structure and values."""
        if not sample_data:
            return False, "No data provided for prediction."
        
        if not isinstance(sample_data, list) or len(sample_data) == 0:
            return False, "Data must be a non-empty list of records."
        
        expected_features = set(self.feature_columns)
        
        for i, record in enumerate(sample_data):
            if not isinstance(record, dict):
                return False, f"Record {i} must be a dictionary."
            
            # Check required features
            missing_features = expected_features - set(record.keys())
            if missing_features:
                return False, f"Record {i} missing features: {list(missing_features)}"
            
            # Basic value validation (adjust based on your feature types)
            for key, value in record.items():
                if key in expected_features:
                    if not isinstance(value, (int, float)):
                        return False, f"Feature '{key}' in record {i} must be numeric."
        
        return True, ""
    
    def predict(self, sample_data: List[Dict[str, Any]]) -> pd.DataFrame:
        """Generate predictions for input data."""
        if not self._is_loaded:
            raise ValidationError("Model not loaded. Call load_model() first.")
        
        is_valid, error_msg = self.validate_sample_data(sample_data)
        if not is_valid:
            raise ValidationError(error_msg)
        
        try:
            # Convert to DataFrame
            df = pd.DataFrame(sample_data)
            
            # Ensure all feature columns exist and reorder
            for col in self.feature_columns:
                if col not in df.columns:
                    df[col] = 0  # Default value for missing features
            
            df = df[self.feature_columns].copy()
            
            # Scale features
            X_scaled = self.scaler.transform(df)
            
            # Generate predictions
            predictions = self.model.predict(X_scaled)
            probabilities = self.model.predict_proba(X_scaled)
            
            # Create results DataFrame
            results = df.copy()
            results['prediction'] = predictions
            results['prediction_class'] = ['Heart Disease' if p == 1 else 'No Heart Disease' for p in predictions]
            results['probability_no_disease'] = probabilities[:, 0]
            results['probability_heart_disease'] = probabilities[:, 1]
            results['confidence'] = np.max(probabilities, axis=1)
            
            logger.info(f"Generated {len(results)} predictions successfully")
            return results
            
        except Exception as e:
            logger.exception(f"Prediction failed: {e}")
            raise ValidationError(f"Prediction failed: {str(e)}")
    
    def generate_csv_response(self, sample_data: List[Dict[str, Any]], filename: str = "heart_disease_predictions.csv") -> 'HttpResponse':
        """Generate CSV HttpResponse for download."""
        from django.http import HttpResponse, Http404
        
        try:
            if not self._is_loaded:
                self.load_model()
            
            results_df = self.predict(sample_data)
            
            # Create CSV response
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = f'attachment; filename="{filename}"'
            
            # Write CSV
            results_df.to_csv(path_or_buf=response, index=False)
            
            logger.info(f"CSV generated successfully with {len(results_df)} records")
            return response
            
        except Exception as e:
            logger.exception(f"CSV generation failed: {e}")
            raise Http404(f"Failed to generate predictions: {str(e)}")