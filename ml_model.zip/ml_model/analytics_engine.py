"""
Analytics Engine – Provides aggregated statistics, cohort analysis,
model performance metrics, and exportable dashboards.
"""

from django.db.models import Count, Avg, Q, F
from django.db.models.functions import TruncMonth, TruncWeek
from .models import Patient, Visit, PredictionHistory
from datetime import timedelta, date
from django.utils import timezone
import pandas as pd
import numpy as np


class AnalyticsEngine:
    """Advanced analytics for population health and model monitoring."""

    @staticmethod
    def get_cohort_stats(age_group=None, gender=None, smoker=None, diabetic=None):
        """Return statistics filtered by cohort."""
        qs = PredictionHistory.objects.all()
        if age_group:
            if age_group == "20-39":
                qs = qs.filter(age__gte=20, age__lte=39)
            elif age_group == "40-59":
                qs = qs.filter(age__gte=40, age__lte=59)
            elif age_group == "60+":
                qs = qs.filter(age__gte=60)
        if gender:
            qs = qs.filter(sex=gender)
        if smoker is not None:
            qs = qs.filter(smoker=smoker)
        if diabetic is not None:
            qs = qs.filter(diabetic=diabetic)

        total = qs.count()
        avg_risk = qs.aggregate(Avg('ml_risk_score'))['ml_risk_score__avg']
        high_risk_count = qs.filter(ml_risk_class=1).count()
        return {
            "total_predictions": total,
            "average_risk_percent": round(avg_risk * 100, 1) if avg_risk else 0,
            "high_risk_percentage": round((high_risk_count / total * 100), 1) if total > 0 else 0,
        }

    @staticmethod
    def get_monthly_trends(months=12):
        """Get monthly average risk scores and prediction counts."""
        end_date = timezone.now()
        start_date = end_date - timedelta(days=30 * months)
        monthly = (
            PredictionHistory.objects.filter(prediction_date__gte=start_date)
            .annotate(month=TruncMonth('prediction_date'))
            .values('month')
            .annotate(
                avg_risk=Avg('ml_risk_score'),
                count=Count('id')
            )
            .order_by('month')
        )
        return [
            {
                "month": item["month"].strftime("%b %Y"),
                "avg_risk": round(item["avg_risk"] * 100, 1) if item["avg_risk"] else 0,
                "count": item["count"],
            }
            for item in monthly
        ]

    @staticmethod
    def get_risk_distribution():
        """Return counts by risk category (Low <0.3, Medium 0.3-0.6, High >0.6)."""
        preds = PredictionHistory.objects.all()
        low = preds.filter(ml_risk_score__lt=0.3).count()
        medium = preds.filter(ml_risk_score__gte=0.3, ml_risk_score__lt=0.6).count()
        high = preds.filter(ml_risk_score__gte=0.6).count()
        return {"Low": low, "Medium": medium, "High": high}

    @staticmethod
    def get_top_risk_factors():
        """
        Analyze correlation between risk factors and high risk predictions.
        Returns percentage of high risk patients with each factor.
        """
        high_risk_preds = PredictionHistory.objects.filter(ml_risk_class=1)
        total_high_risk = high_risk_preds.count()
        if total_high_risk == 0:
            return {}
        stats = {
            "smoker": high_risk_preds.filter(smoker=True).count() / total_high_risk * 100,
            "diabetic": high_risk_preds.filter(diabetic=True).count() / total_high_risk * 100,
            "family_history": high_risk_preds.filter(family_history=True).count() / total_high_risk * 100,
            "hypertension": high_risk_preds.filter(systolic_bp__gt=140).count() / total_high_risk * 100,
            "age_60_plus": high_risk_preds.filter(age__gte=60).count() / total_high_risk * 100,
        }
        return {k: round(v, 1) for k, v in stats.items()}

    @staticmethod
    def get_patient_engagement_metrics():
        """Return average visits per patient, prediction frequency, etc."""
        total_patients = Patient.objects.count()
        total_visits = Visit.objects.count()
        total_predictions = PredictionHistory.objects.count()
        return {
            "avg_visits_per_patient": round(total_visits / total_patients, 1) if total_patients else 0,
            "avg_predictions_per_patient": round(total_predictions / total_patients, 1) if total_patients else 0,
            "patients_with_high_risk": PredictionHistory.objects.filter(ml_risk_class=1).values('patient').distinct().count(),
        }

    @staticmethod
    def export_to_dataframe():
        """Export all predictions to pandas DataFrame for external analysis."""
        qs = PredictionHistory.objects.select_related('patient', 'visit').all().values()
        df = pd.DataFrame(list(qs))
        return df