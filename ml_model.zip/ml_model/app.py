from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
import joblib
import numpy as np
import os
from pydantic import BaseModel
import uvicorn

app = FastAPI(title="Heart Disease API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load model
model = joblib.load('saved_models/heart_model.pkl')
scaler = joblib.load('saved_models/scaler.pkl')
feature_names = joblib.load('saved_models/feature_columns.pkl')

print("✅ All models loaded!")

class HeartData(BaseModel):
    age: float = 50
    sex: float = 1
    cp: float = 2
    trestbps: float = 120
    chol: float = 250
    fbs: float = 0
    restecg: float = 0
    thalach: float = 160
    exang: float = 0
    oldpeak: float = 1.5
    slope: float = 2
    ca: float = 0
    thal: float = 2

@app.get("/", response_class=HTMLResponse)
async def root():
    return """
    <h1>❤️ Heart Disease API READY!</h1>
    <p><a href="/docs">📚 API Docs</a> | <a href="/predict-test">🧪 Test Prediction</a></p>
    <p>Backend: ✅ Working | Model: ✅ Loaded</p>
    """

@app.get("/predict-test")
async def test_predict():
    # Dummy prediction
    features = np.random.rand(1, 13)
    features_scaled = scaler.transform(features)
    pred = model.predict(features_scaled)[0]
    return {"test_prediction": int(pred), "message": "API works!"}

@app.post("/predict")
async def predict(data: HeartData):
    features = np.array([[data.age, data.sex, data.cp, data.trestbps, data.chol,
                         data.fbs, data.restecg, data.thalach, data.exang,
                         data.oldpeak, data.slope, data.ca, data.thal]])
    
    features_scaled = scaler.transform(features)
    prediction = model.predict(features_scaled)[0]
    probability = model.predict_proba(features_scaled)[0]
    
    return {
        "prediction": int(prediction),
        "risk": "🚨 HIGH RISK" if prediction == 1 else "✅ LOW RISK",
        "confidence": f"{float(max(probability)*100):.1f}%",
        "probabilities": {
            "no_disease": f"{float(probability[0]*100):.1f}%",
            "disease": f"{float(probability[1]*100):.1f}%"
        }
    }

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)  # Changed to localhost
    