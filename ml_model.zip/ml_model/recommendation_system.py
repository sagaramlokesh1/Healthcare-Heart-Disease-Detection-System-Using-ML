"""
Recommendation System – Generates personalized lifestyle, diet, and medical advice
based on patient risk factors, clinical scores, and historical data.
"""

from .models import PredictionHistory, Patient, Visit
from django.utils import timezone
from datetime import timedelta


class RecommendationSystem:
    """Generates actionable recommendations for patients."""

    @staticmethod
    def get_lifestyle_recommendations(risk_score, smoker, diabetic, hypertensive, age):
        """Return lifestyle advice based on risk profile."""
        advice = []
        if risk_score > 0.6:
            advice.append("⚠️ High risk detected: consult cardiologist within 2 weeks.")
            advice.append("🚭 Quit smoking immediately – use nicotine replacement therapy.")
            advice.append("🚶 Start with 15 min daily walking, increase gradually to 45 min.")
        elif risk_score > 0.3:
            advice.append("📉 Moderate risk: lifestyle changes can reduce risk.")
            advice.append("🚶 Exercise 30 minutes, 5 days a week (brisk walking, cycling).")
            advice.append("🥗 Reduce saturated fats; increase fruits, vegetables, whole grains.")
        else:
            advice.append("✅ Low risk: maintain healthy habits.")
            advice.append("🏃‍♂️ Stay active – 150 min moderate exercise per week.")
            advice.append("🍎 Balanced diet rich in fiber and lean protein.")

        if smoker:
            advice.append("🔥 Smoking cessation reduces heart risk by 50% in 1 year.")
        if diabetic:
            advice.append("📊 Monitor blood glucose daily. Aim HbA1c < 7%.")
        if hypertensive or risk_score > 0.4:
            advice.append("❤️ Monitor BP at home. Target < 130/80 mmHg.")
        if age > 65:
            advice.append("👴 Annual comprehensive geriatric assessment recommended.")

        return advice

    @staticmethod
    def get_dietary_plan(cholesterol, glucose, bmi=25):
        """Return diet suggestions based on lab values."""
        plan = []
        if cholesterol > 200:
            plan.append("🚫 Limit red meat, butter, fried foods.")
            plan.append("🌾 Increase soluble fiber: oats, barley, beans, apples.")
        if glucose > 140:
            plan.append("🍬 Reduce refined sugars and sweetened beverages.")
            plan.append("🥑 Eat low glycemic index foods (non-starchy vegetables, legumes).")
        if bmi > 30:
            plan.append("⚖️ Weight loss of 5-10% can significantly lower cardiovascular risk.")
        if not plan:
            plan.append("🥦 Mediterranean diet: fish, olive oil, nuts, plenty of vegetables.")
        return plan

    @staticmethod
    def get_medical_follow_up(risk_class, age, diabetic):
        """Recommend next visit timeline and tests."""
        if risk_class == 1:  # high risk
            return {
                "next_visit": "2 weeks",
                "tests": ["Lipid panel", "HbA1c", "ECG", "Stress test"],
                "medication_review": True
            }
        elif risk_class == 0 and age > 60:
            return {
                "next_visit": "3 months",
                "tests": ["Lipid panel", "Blood pressure check"],
                "medication_review": False
            }
        else:
            return {
                "next_visit": "12 months",
                "tests": ["Annual physical", "Cholesterol check"],
                "medication_review": False
            }

    @staticmethod
    def generate_full_plan(patient_id, prediction_id=None):
        """
        Generate comprehensive plan using most recent prediction or specific one.
        Returns dict with lifestyle, diet, medical follow-up.
        """
        if prediction_id:
            pred = PredictionHistory.objects.get(id=prediction_id)
        else:
            pred = PredictionHistory.objects.filter(patient_id=patient_id).order_by('-prediction_date').first()
        if not pred:
            return {"error": "No predictions found for this patient"}

        patient = pred.patient
        risk_score = pred.ml_risk_score
        risk_class = pred.ml_risk_class
        smoker = pred.smoker
        diabetic = pred.diabetic
        hypertensive = pred.systolic_bp > 140
        age = patient.age
        cholesterol = pred.cholesterol
        # get latest glucose from visit (need to fetch visit)
        visit = pred.visit
        glucose = visit.glucose if visit else 120

        lifestyle = RecommendationSystem.get_lifestyle_recommendations(risk_score, smoker, diabetic, hypertensive, age)
        diet = RecommendationSystem.get_dietary_plan(cholesterol, glucose)
        medical = RecommendationSystem.get_medical_follow_up(risk_class, age, diabetic)

        return {
            "lifestyle": lifestyle,
            "diet": diet,
            "medical": medical,
            "risk_score_percent": round(risk_score * 100, 1),
            "generated_at": timezone.now().isoformat()
        }