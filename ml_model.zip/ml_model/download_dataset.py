#!/usr/bin/env python3
"""
Automated dataset download script with error handling and integrity verification.
Downloads heart.csv from Kaggle/UCI repository.
"""

import os
import requests
import pandas as pd
from pathlib import Path
import hashlib
import sys
from typing import Optional

def download_file(url: str, filepath: Path, expected_hash: Optional[str] = None, chunk_size: int = 8192) -> bool:
    """Download file with progress tracking and integrity verification."""
    try:
        response = requests.get(url, stream=True, timeout=30)
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        downloaded = 0
        
        with open(filepath, 'wb') as f:
            for chunk in response.iter_content(chunk_size=chunk_size):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        progress = (downloaded / total_size) * 100
                        print(f"\rDownloading: {progress:.1f}%", end='', flush=True)
        
        print(f"\n✓ Downloaded to {filepath}")
        
        # Verify file integrity if hash provided
        if expected_hash:
            with open(filepath, 'rb') as f:
                file_hash = hashlib.md5(f.read()).hexdigest()
                if file_hash == expected_hash:
                    print("✓ File integrity verified")
                    return True
                else:
                    print(f"✗ Hash mismatch! Expected: {expected_hash}, Got: {file_hash}")
                    return False
        
        return True
        
    except requests.exceptions.RequestException as e:
        print(f"✗ Download failed: {e}")
        return False

def main():
    ml_model_dir = Path("ml_model")
    dataset_path = ml_model_dir / "heart.csv"
    
    # Create directory if it doesn't exist
    ml_model_dir.mkdir(exist_ok=True)
    
    if dataset_path.exists():
        print(f"Dataset already exists at {dataset_path}")
        print("File size:", dataset_path.stat().st_size, "bytes")
        sys.exit(0)
    
    # Primary source: Kaggle UCI Heart Disease (direct CSV)
    primary_url = "https://raw.githubusercontent.com/jbrownlee/Datasets/master/heart-disease.csv"
    expected_hash = "d4a18ce8905072fe7892b1d5f649b878"  # MD5 of expected file
    
    print("Downloading heart disease dataset...")
    success = download_file(primary_url, dataset_path, expected_hash)
    
    if not success:
        print("Primary download failed. Trying backup source...")
        backup_url = "https://archive.ics.uci.edu/ml/machine-learning-databases/heart-disease/processed.cleveland.data"
        success = download_file(backup_url, dataset_path)
    
    if success and dataset_path.exists():
        df = pd.read_csv(dataset_path)
        print(f"\nDataset loaded successfully!")
        print(f"Shape: {df.shape}")
        print(f"Columns: {list(df.columns)}")
        print("\nFirst 5 rows:")
        print(df.head())
    else:
        print("✗ Failed to download dataset. Please check your internet connection.")
        sys.exit(1)

if __name__ == "__main__":
    main()