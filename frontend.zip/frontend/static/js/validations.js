function validateMedicalForm(form) {
    const errors = [];
    const age = form.querySelector('[name="age"]')?.value;
    const systolic = form.querySelector('[name="systolic_bp"]')?.value;
    const diastolic = form.querySelector('[name="diastolic_bp"]')?.value;

    if (age && (age < 0 || age > 120)) errors.push('Age must be between 0 and 120.');
    if (systolic && (systolic < 50 || systolic > 250)) errors.push('Systolic BP must be 50–250 mmHg.');
    if (diastolic && (diastolic < 30 || diastolic > 150)) errors.push('Diastolic BP must be 30–150 mmHg.');
    if (systolic && diastolic && parseInt(systolic) <= parseInt(diastolic))
        errors.push('Systolic BP must be greater than diastolic BP.');
    return errors;
}
window.validateMedicalForm = validateMedicalForm;