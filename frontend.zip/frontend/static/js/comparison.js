// comparison.js – Handles patient selection and comparison results

document.addEventListener('DOMContentLoaded', function() {
    const patientASelect = document.getElementById('patientA');
    const patientBSelect = document.getElementById('patientB');
    const compareBtn = document.getElementById('compareBtn');
    const resultsContainer = document.getElementById('comparisonResults');

    async function loadPatients() {
        const response = await fetch('/api/patients/simple/');
        const patients = await response.json();
        const options = patients.map(p => `<option value="${p.id}">${p.name} (${p.age})</option>`);
        if (patientASelect) patientASelect.innerHTML = options;
        if (patientBSelect) patientBSelect.innerHTML = options;
    }

    async function comparePatients(pid1, pid2) {
        resultsContainer.innerHTML = '<div class="text-center"><div class="spinner-border"></div> Loading...</div>';
        try {
            const response = await fetch(`/api/compare/${pid1}/${pid2}/`);
            const data = await response.json();
            renderComparisonResults(data);
        } catch (err) {
            resultsContainer.innerHTML = '<div class="alert alert-danger">Comparison failed</div>';
        }
    }

    function renderComparisonResults(data) {
        const metrics = ['age', 'systolic_bp', 'cholesterol', 'glucose', 'risk_score'];
        let html = '<table class="table table-bordered"><thead><tr><th>Metric</th><th>Patient A</th><th>Patient B</th></tr></thead><tbody>';
        metrics.forEach(m => {
            html += `<tr>
                        <td>${m.replace('_', ' ').toUpperCase()}</td>
                        <td>${data.patient_a[m] || 'N/A'}</td>
                        <td>${data.patient_b[m] || 'N/A'}</td>
                     </tr>`;
        });
        html += `</tbody></table>
                 <div class="alert alert-info">Risk difference: ${data.risk_difference} points</div>`;
        resultsContainer.innerHTML = html;
    }

    if (compareBtn) {
        compareBtn.addEventListener('click', () => {
            const pid1 = patientASelect.value;
            const pid2 = patientBSelect.value;
            if (pid1 === pid2) {
                alert('Please select two different patients');
                return;
            }
            comparePatients(pid1, pid2);
        });
        loadPatients();
    }
});