window.MedPredict = {
    apiBase: '/api',
    token: null,

    async request(endpoint, options = {}) {
        const url = this.apiBase + endpoint;
        const headers = { 'Content-Type': 'application/json' };
        if (this.token) headers['Authorization'] = `Bearer ${this.token}`;
        try {
            const response = await fetch(url, { ...options, headers });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            return await response.json();
        } catch (err) {
            console.error('API Error:', err);
            this.showToast(err.message, 'error');
            throw err;
        }
    },

    showToast(message, type = 'info') {
        const container = document.getElementById('flash-messages');
        if (!container) return;
        const toast = document.createElement('div');
        toast.className = `alert alert-${type}`;
        toast.textContent = message;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 4000);
    }
};

// Toggle sidebar and mobile nav
document.addEventListener('DOMContentLoaded', () => {
    const toggleBtn = document.getElementById('nav-toggle');
    const sidebar = document.getElementById('sidebar');
    const navLinks = document.getElementById('nav-links');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            if (sidebar) sidebar.classList.toggle('open');
            if (navLinks) navLinks.classList.toggle('open');
        });
    }
    // Auto-dismiss flash messages
    document.querySelectorAll('.alert').forEach(alert => {
        setTimeout(() => alert.style.opacity = '0', 4000);
        setTimeout(() => alert.remove(), 5000);
    });
});