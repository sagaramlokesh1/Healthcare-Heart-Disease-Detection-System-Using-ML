async function refreshDashboardStats() {
    try {
        const response = await fetch('/api/dashboard/stats');
        if (!response.ok) throw new Error('Network error');
        const data = await response.json();
        const statContainer = document.querySelector('.dashboard-stats');
        if (statContainer) {
            statContainer.innerHTML = `
                <div class="stat-card">Total Predictions: ${data.total_predictions}</div>
                <div class="stat-card">High Risk Cases: ${data.high_risk}</div>
                <div class="stat-card">Patients: ${data.total_patients}</div>
            `;
        }
        if (window.initDashboardCharts && data.risk_trend) {
            window.initDashboardCharts(data.risk_trend);
        }
    } catch (err) {
        console.error('Dashboard stats error:', err);
        if (window.MedPredict) window.MedPredict.showToast('Could not refresh dashboard stats', 'error');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.dashboard-stats')) {
        refreshDashboardStats();
        setInterval(refreshDashboardStats, 60000);
    }
});