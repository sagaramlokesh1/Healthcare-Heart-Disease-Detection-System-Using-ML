// appointment.js – Handles appointment scheduling, editing, and cancellation

document.addEventListener('DOMContentLoaded', function() {
    // Initialize date picker if needed
    const datetimeInput = document.querySelector('#appointment-datetime');
    if (datetimeInput) {
        datetimeInput.min = new Date().toISOString().slice(0, 16);
    }

    // Book appointment form submission
    const bookForm = document.querySelector('#book-appointment-form');
    if (bookForm) {
        bookForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const formData = new FormData(bookForm);
            try {
                const response = await fetch('/api/appointments/', {
                    method: 'POST',
                    body: formData,
                    headers: { 'X-CSRFToken': getCookie('csrftoken') }
                });
                const data = await response.json();
                if (response.ok) {
                    showToast('Appointment booked successfully!', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(data.error || 'Booking failed', 'danger');
                }
            } catch (err) {
                showToast('Network error', 'danger');
            }
        });
    }

    // Cancel appointment
    document.querySelectorAll('.cancel-appointment').forEach(btn => {
        btn.addEventListener('click', async function() {
            const appId = this.dataset.id;
            if (confirm('Cancel this appointment?')) {
                const response = await fetch(`/api/appointments/${appId}/cancel/`, {
                    method: 'POST',
                    headers: { 'X-CSRFToken': getCookie('csrftoken') }
                });
                if (response.ok) {
                    showToast('Appointment cancelled', 'success');
                    this.closest('.appointment-card').remove();
                } else {
                    showToast('Cancel failed', 'danger');
                }
            }
        });
    });
});

// Helper: show Bootstrap toasts
function showToast(message, type) {
    const toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        const container = document.createElement('div');
        container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(container);
    }
    const toastHtml = `
        <div class="toast align-items-center text-white bg-${type} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>`;
    const toastEl = $(toastHtml);
    $('.toast-container').append(toastEl);
    const toast = new bootstrap.Toast(toastEl);
    toast.show();
    setTimeout(() => toastEl.remove(), 3000);
}

// CSRF token helper for Django
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}