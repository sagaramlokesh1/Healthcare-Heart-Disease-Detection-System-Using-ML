// analytics.js – Creates dynamic charts using Chart.js for the analytics dashboard

function initAnalyticsCharts(riskDistribution, monthlyTrend, riskProgression) {
    // Risk distribution pie chart
    const riskCtx = document.getElementById('riskDistributionChart')?.getContext('2d');
    if (riskCtx && riskDistribution) {
        new Chart(riskCtx, {
            type: 'doughnut',
            data: {
                labels: ['Low Risk', 'Medium Risk', 'High Risk'],
                datasets: [{
                    data: [riskDistribution.low, riskDistribution.medium, riskDistribution.high],
                    backgroundColor: ['#198754', '#ffc107', '#dc3545'],
                    borderWidth: 0
                }]
            },
            options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
        });
    }

    // Monthly trend line chart
    const trendCtx = document.getElementById('monthlyTrendChart')?.getContext('2d');
    if (trendCtx && monthlyTrend && monthlyTrend.labels) {
        new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: monthlyTrend.labels,
                datasets: [{
                    label: 'Avg Risk Score (%)',
                    data: monthlyTrend.data,
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13,110,253,0.1)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: { responsive: true, scales: { y: { beginAtZero: true, max: 100 } } }
        });
    }

    // Patient risk progression (if multiple predictions per patient)
    const progCtx = document.getElementById('riskProgressionChart')?.getContext('2d');
    if (progCtx && riskProgression) {
        new Chart(progCtx, {
            type: 'line',
            data: {
                labels: riskProgression.dates,
                datasets: [{
                    label: 'Risk Score',
                    data: riskProgression.scores,
                    borderColor: '#fd7e14',
                    fill: false
                }]
            }
        });
    }
}

// Auto-initialize when DOM ready (assuming data is injected via data-attributes or window object)
document.addEventListener('DOMContentLoaded', function() {
    const analyticsData = window.analyticsData || {};
    initAnalyticsCharts(
        analyticsData.riskDistribution,
        analyticsData.monthlyTrend,
        analyticsData.riskProgression
    );
});