function drawBarChart(canvasId, labels, data, title = '') {
    const canvas = document.getElementById(canvasId);
    if (!canvas || !canvas.getContext) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width, height = canvas.height;
    ctx.clearRect(0, 0, width, height);
    if (!data.length) {
        ctx.fillText('No data', width/2, height/2);
        return;
    }
    const maxVal = Math.max(...data, 1);
    const barWidth = (width / data.length) * 0.7;
    const startX = (width / data.length - barWidth) / 2;
    ctx.fillStyle = '#0056b3';
    for (let i = 0; i < data.length; i++) {
        const barHeight = (data[i] / maxVal) * (height - 50);
        const x = i * (width / data.length) + startX;
        const y = height - barHeight - 20;
        ctx.fillRect(x, y, barWidth, barHeight);
        ctx.fillStyle = '#333';
        ctx.font = '10px sans-serif';
        ctx.fillText(labels[i], x, height - 5);
        ctx.fillStyle = '#0056b3';
    }
    if (title) {
        ctx.fillStyle = '#000';
        ctx.font = 'bold 14px sans-serif';
        ctx.fillText(title, width/2 - 30, 15);
    }
}

function drawRiskDistribution(riskData) {
    const labels = Object.keys(riskData);
    const values = Object.values(riskData);
    drawBarChart('risk-distribution', labels, values, 'Risk Distribution');
}

function drawTimeSeries(timeData) {
    const labels = timeData.map(d => d.date);
    const values = timeData.map(d => d.count);
    drawBarChart('predictions-over-time', labels, values, 'Predictions Over Time');
}
// charts.js
function initDashboardCharts(riskData) {
    const canvas = document.getElementById('riskTrendChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    canvas.width = width;
    canvas.height = height;
    ctx.clearRect(0, 0, width, height);
    if (!riskData || riskData.length === 0) return;
    const maxVal = Math.max(...riskData, 1);
    const stepX = width / (riskData.length - 1 || 1);
    ctx.beginPath();
    ctx.moveTo(0, height - (riskData[0] / maxVal) * (height - 40));
    for (let i = 1; i < riskData.length; i++) {
        const x = i * stepX;
        const y = height - (riskData[i] / maxVal) * (height - 40);
        ctx.lineTo(x, y);
    }
    ctx.strokeStyle = '#0056b3';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = '#333';
    ctx.fillText('Risk Trend', width/2 - 30, 15);
}
window.initDashboardCharts = initDashboardCharts;

window.drawBarChart = drawBarChart;
window.drawRiskDistribution = drawRiskDistribution;
window.drawTimeSeries = drawTimeSeries;
