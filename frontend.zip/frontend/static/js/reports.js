document.addEventListener('DOMContentLoaded', () => {
    const filterBtn = document.getElementById('filter-reports');
    if (filterBtn) {
        filterBtn.addEventListener('click', async () => {
            const fromDate = document.getElementById('from-date')?.value;
            const toDate = document.getElementById('to-date')?.value;
            const params = new URLSearchParams();
            if (fromDate) params.append('from', fromDate);
            if (toDate) params.append('to', toDate);
            try {
                const response = await fetch(`/api/reports?${params.toString()}`);
                if (!response.ok) throw new Error('Failed to fetch reports');
                const reports = await response.json();
                const tbody = document.querySelector('#reports-table tbody');
                if (tbody) {
                    tbody.innerHTML = reports.map(r => `
                        <tr>
                            <td data-label="Report ID">${r.id}</td>
                            <td data-label="Date">${r.date}</td>
                            <td data-label="Patient">${r.patient_name}</td>
                            <td data-label="Risk">${r.risk_level}</td>
                            <td data-label="Actions"><a href="/report_preview/${r.id}">Preview</a></td>
                        </tr>
                    `).join('');
                }
            } catch (err) {
                console.error(err);
                if (window.MedPredict) window.MedPredict.showToast('Failed to load reports', 'error');
            }
        });
    }
});