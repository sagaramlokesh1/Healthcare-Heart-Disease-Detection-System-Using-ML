// notifications.js – Fetch, display, and mark notifications as read

document.addEventListener('DOMContentLoaded', function() {
    loadNotifications();

    // Mark single notification as read
    document.querySelectorAll('.mark-read').forEach(btn => {
        btn.addEventListener('click', async function() {
            const notifId = this.dataset.id;
            await fetch(`/api/notifications/${notifId}/read/`, { method: 'POST' });
            this.closest('.notification-item').classList.add('opacity-50');
        });
    });

    // Mark all as read
    const markAllBtn = document.querySelector('#mark-all-read');
    if (markAllBtn) {
        markAllBtn.addEventListener('click', async function() {
            await fetch('/api/notifications/mark-all-read/', { method: 'POST' });
            location.reload();
        });
    }
});

async function loadNotifications() {
    const container = document.querySelector('#notifications-list');
    if (!container) return;
    try {
        const response = await fetch('/api/notifications/');
        const notifs = await response.json();
        if (notifs.length === 0) {
            container.innerHTML = '<p class="text-muted text-center">No notifications</p>';
            return;
        }
        container.innerHTML = notifs.map(n => `
            <div class="list-group-item notification-item ${n.read ? 'bg-light' : 'bg-white'}">
                <div class="d-flex justify-content-between">
                    <div>
                        <strong>${n.title}</strong>
                        <br><small class="text-muted">${n.message}</small>
                        <div class="text-muted small">${new Date(n.created_at).toLocaleString()}</div>
                    </div>
                    ${!n.read ? `<button class="btn btn-sm btn-outline-primary mark-read" data-id="${n.id}">Mark read</button>` : ''}
                </div>
            </div>
        `).join('');
        // reattach event listeners
        document.querySelectorAll('.mark-read').forEach(btn => {
            btn.addEventListener('click', async function() {
                const id = this.dataset.id;
                await fetch(`/api/notifications/${id}/read/`, { method: 'POST' });
                this.closest('.notification-item').classList.add('bg-light');
                this.remove();
            });
        });
    } catch (err) {
        console.error('Failed to load notifications', err);
    }
}